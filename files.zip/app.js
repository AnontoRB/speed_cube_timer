// Plain JavaScript core, so the timer always works. If the Rust/WebAssembly build exists in pkg/, it replaces these.
const R = n => Math.floor(Math.random() * n), pk = a => a[R(a.length)];

let scramble = ev => {
  const n = ev === '2' ? 2 : ev === '4' ? 4 : ev === '5' ? 5 : 3,
        len = { 2: 9, 3: 20, 4: 40, 5: 60 }[n],
        fs = 'URFDLB'.slice(0, n == 2 ? 3 : 6);
  let o = [], la = -1;
  while (o.length < len) {
    const f = R(fs.length), a = f % 3;
    if (a === la) continue;
    la = a;
    o.push(fs[f] + ((n > 3 && R(2)) ? 'w' : '') + pk(['', "'", '2']));
  }
  return o.join(' ');
};

let F = (ms, dec) => {
  if (!isFinite(ms)) return 'DNF';
  const d = dec == 3 ? 3 : 2, den = d == 3 ? 1000 : 100, s = Math.floor(ms / (d == 3 ? 1 : 10)) / den;
  if (s >= 60) {
    const m = Math.floor(s / 60);
    return m + ':' + (s - m * 60).toFixed(d).padStart(d + 3, '0');
  }
  return s.toFixed(d);
};

let ao5 = v => {
  if (v.length < 5) return NaN;
  if (v.filter(x => x === Infinity).length > 1) return Infinity;
  const s = [...v].sort((a, b) => a === b ? 0 : a - b);
  return (s[1] + s[2] + s[3]) / 3;
};

let stats = v => {
  const fin = [...v].filter(isFinite);
  let b = NaN;
  for (let i = 5; i <= v.length; i++) {
    const x = ao5(v.slice(i - 5, i));
    if (isNaN(b) || x < b) b = x;
  }
  return [fin.length ? Math.min(...fin) : NaN, fin.length ? fin.reduce((a, c) => a + c) / fin.length : NaN, v.length >= 5 ? ao5(v.slice(-5)) : NaN, b];
};

let insp = s => s >= 17 ? -1 : s > 15 ? 2 : 0,
    insp_text = s => s < 15 ? String(Math.ceil(15 - s)) : '+2';

if (location.protocol.startsWith('http') && 'serviceWorker' in navigator) {
  navigator.serviceWorker.register('sw.js').catch(() => {});
}

const $ = s => document.querySelector(s),
      tm = $('#tm'),
      dl = $('#dl');

const allCubes = () => [...CUBES, ...(typeof PRAC !== 'undefined' ? PRAC : []), ...(S.custom || [])],
      curCube = () => allCubes().find(c => c.id === S.cur) || CUBES[1];
const PRE = { dark: { bg: '#14161a', fg: '#eef0f3', ac: '#5b9dff' }, light: { bg: '#f6f7f9', fg: '#15181d', ac: '#2563eb' } };
const th = matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark';

const defSet = () => ({
  theme: th, ...PRE[th], rd: '#2ecc71', hd: '#e74c3c', fs: 96, ss: 18, hold: 300, insp: true, snd: true, vol: 60, auto: true, hide: false, secs: false, dec: 2, showScr: true, focus: true,
  tone: 'fun', det: 'full', fx: true, fxi: 2, sfx: true, pbm: true, pbS: true, pb5: true, pb12: true, pb50: true, pb100: true, rdy: true, vib: true, brk: true, goal: 20, typing: false, rnd: false,
  tf: 'system', tw: 600, sfm: true, ui: 100, rad: 8, th: 42, showRs: true, showSt: true, showSide: true, showMenu: true, showGoal: true, showSk: true, showWk: true, showTl: true, showRd: true, wallDim: 45, cardOp: 72, sideOp: null, keepScr: 'all'
});

let WALL = '';
try { WALL = localStorage.getItem('ct2wall') || ''; if (!/^data:image\//.test(WALL)) WALL = ''; } catch (e) {}

const FONTS = { system: 'inherit', mono: 'ui-monospace, Menlo, Consolas, monospace', serif: "Georgia, 'Times New Roman', serif", rounded: "ui-rounded, 'Segoe UI', system-ui, sans-serif" };

let S = {
  set: defSet(),
  cur: '3',
  data: {}
};

// ---- Saved data (start) ----
// Everything except the past days is kept under the key ct2 (small, rewritten after every solve).
// Each past day has its own key, ct2h:YYYY-MM-DD, and is written (and uploaded) only when it really changed.
// Older versions kept the history inside ct2; it is moved over automatically the first time.
const HK = 'ct2h:';
const histH = {}, histL = {}, histU = {};   // fingerprint of every past day: now / saved on this device / sent to the server
const histNew = {};                          // days whose text must still be written to this device
let histCheck = true;                        // true = compare every past day with its last fingerprint before the next save
const hsh = s => { let h = 2166136261; for (let i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619); return s.length + ':' + (h >>> 0); };

function scanHist() {
  histCheck = false;
  const hh = S.hist || {};
  for (const d in hh) {
    if (!Object.keys(hh[d]).length) { delete hh[d]; continue; }   // a day with no cubes left is not kept
    const str = JSON.stringify(hh[d]), h = hsh(str);
    histH[d] = h;
    if (histL[d] !== h) histNew[d] = str;
  }
  for (const d in histH) if (!(d in hh)) { delete histH[d]; delete histNew[d]; }
}

function persist() {
  if (LOCKED) return;
  try {
    if (histCheck) scanHist();
    for (const d in histNew) { localStorage.setItem(HK + d, histNew[d]); histL[d] = histH[d]; delete histNew[d]; }
    for (const d in histL) if (!(d in histH)) { localStorage.removeItem(HK + d); delete histL[d]; }
    const { hist, ...core } = S;
    localStorage.setItem('ct2', JSON.stringify(core));
  } catch (e) { warnStorage(); }
}

// Optional: drop the scramble text of solves older than the chosen number of days (times are kept).
function trimScr() {
  const n = +S.set.keepScr;
  if (!n) return false;
  const cut = dkey(Date.now() - n * 864e5);
  let ch = false;
  for (const day in S.hist) {
    if (day >= cut) continue;
    for (const id in S.hist[day]) for (const s of S.hist[day][id].solves) if (s.s) { delete s.s; ch = true; }
  }
  if (ch) histCheck = true;
  return ch;
}

try {
  const j = JSON.parse(localStorage.getItem('ct2') || 'null');
  if (j) S = { ...S, ...j, set: { ...S.set, ...j.set } };
} catch (e) {}
S.hist = S.hist || {};
try {
  for (let i = 0; i < localStorage.length; i++) {
    const k = localStorage.key(i);
    if (!k || !k.startsWith(HK)) continue;
    try { const t = localStorage.getItem(k), d = k.slice(HK.length); S.hist[d] = JSON.parse(t); histL[d] = hsh(t); } catch (e) {}
  }
} catch (e) {}
scanHist();
// ---- Saved data (end) ----

S.data = S.data || {};
S.known = S.known || {};
S.view = S.view || { m: 'cfop', t: 'ov' };
S.hist = S.hist || {};
S.rec = S.rec || {};

try { navigator.storage.persist(); } catch (e) {}

// ---- Accounts and server sync ----
// '' = the server that serves this page (server.js). If the website is hosted somewhere else
// (for example GitHub Pages), put the address of your server here, e.g. 'https://cubetimer.example.com'.
const API_BASE = 'https://cubetimer-api.anontoorb.workers.dev';
const apiUrl = p => (API_BASE ? API_BASE.replace(/\/+$/, '') + '/' : '') + 'api/' + p;
const SYNC_TXT = { off: 'Not signed in', busy: 'Syncing…', ok: 'All changes are saved on the server', err: 'Cannot reach the server. Your solves are safe on this computer and will sync later.' };
let AUTH = null, syncSt = 'off', pt, pushing = false, pushAgain = false, retry409 = 0, LOCKED = false;
try { AUTH = JSON.parse(localStorage.getItem('ct2auth') || 'null'); } catch (e) {}
if (!AUTH || !AUTH.token || !AUTH.user) AUTH = null;
if (AUTH) syncSt = 'busy';

const setAuth = a => {
  AUTH = a;
  try { if (a) localStorage.setItem('ct2auth', JSON.stringify(a)); else localStorage.removeItem('ct2auth'); } catch (e) {}
};
// the server time of the last state this computer and the server agreed on (per account)
const syncedTs = () => { try { const j = JSON.parse(localStorage.getItem('ct2sync') || 'null'); return j && AUTH && j.u === AUTH.user ? +j.ts || 0 : 0; } catch (e) { return 0; } };
const setSyncedTs = ts => { try { localStorage.setItem('ct2sync', JSON.stringify({ u: AUTH ? AUTH.user : '', ts })); } catch (e) {} };

// Upload only what changed. fullPush = the next upload sends everything (first upload, after a merge, ...).
// canDelta = the server told us it understands partial uploads (an older server would treat a partial upload as the whole state).
let fullPush = true, canDelta = false;
if (AUTH && S.ts && (S.ts || 0) <= syncedTs()) { Object.assign(histU, histH); fullPush = false; }   // nothing changed on this device since the last upload

function setSync(st) {
  syncSt = st;
  updateAcct();
}

function updateAcct() {
  const b = document.querySelector('[data-a="acct"]');
  if (b) {
    const tx = b.querySelector('.tx');
    if (tx) tx.textContent = AUTH ? AUTH.user : 'Log in';
    b.title = AUTH ? 'Account: ' + AUTH.user + ' · ' + SYNC_TXT[syncSt] : 'Log in or create an account to keep your solves on every computer';
    b.classList.toggle('on', !!AUTH);
  }
  const el = document.getElementById('acst');
  if (el) el.textContent = SYNC_TXT[syncSt];
}

async function api(path, method = 'GET', body) {
  const h = {};
  if (body !== undefined) h['Content-Type'] = 'application/json';
  if (AUTH) h.Authorization = 'Bearer ' + AUTH.token;
  let r;
  try { r = await fetch(apiUrl(path), { method, headers: h, cache: 'no-store', body: body === undefined ? undefined : JSON.stringify(body) }); }
  catch (e) { const err = new Error('Cannot reach the server. Check your internet connection.'); err.status = 0; throw err; }
  let j = null;
  try { j = await r.json(); } catch (e) {}
  if (!r.ok) {
    if (r.status === 401 && AUTH && path !== 'login' && path !== 'register') { setAuth(null); setSync('off'); }   // session ended
    const err = new Error((j && j.error) || 'Server error (' + r.status + ')');
    err.status = r.status;
    throw err;
  }
  return j || {};
}

// Sends the whole state to the account shortly after every change.
// which kinds of personal best get the confetti, music and gold theme (the message text is always shown)
const pbOn = k => S.set[k] !== false;

const push = () => {
  if (!location.protocol.startsWith('http') || !AUTH) return;
  clearTimeout(pt);
  pt = setTimeout(doPush, 800);
};

async function doPush() {
  if (!AUTH) return false;
  if (pushing) { pushAgain = true; return false; }
  pushing = true;
  setSync('busy');
  let ok = false;
  try {
    if (!S.ts) S.ts = Date.now();
    if (histCheck) scanHist();
    const ts = S.ts, delta = canDelta && !fullPush, sent = { ...histH };
    let body = S;
    if (delta) {   // everything except the past days, plus only the past days that changed (null = removed)
      const { hist, ...core } = S, days = {};
      for (const d in histH) if (histH[d] !== histU[d]) days[d] = S.hist[d];
      for (const d in histU) if (!(d in histH)) days[d] = null;
      body = { ...core, delta: true, hist: days };
    }
    const r = await api('state?base=' + syncedTs(), 'PUT', body);
    if (r.d) canDelta = true;
    for (const d in histU) delete histU[d];
    Object.assign(histU, sent);
    fullPush = false;
    setSyncedTs(r.ts || ts);
    retry409 = 0;
    setSync('ok');
    ok = true;
  } catch (e) {
    if (e.status === 409 && ++retry409 < 4) setTimeout(pull, 0);   // the server has newer data: merge it in first
    else setSync(AUTH ? 'err' : 'off');
  }
  pushing = false;
  if (pushAgain) { pushAgain = false; push(); }
  return ok;
}

let quotaWarned = false;
function warnStorage() {
  if (quotaWarned) return;
  quotaWarned = true;
  const m = document.getElementById('msg');
  if (m) m.textContent = 'Warning: this browser could not save your solves on this device (storage is full). Export your data in Settings, or remove the wallpaper.';
}
const save = () => {
  if (LOCKED) return;
  S.ts = Math.max(Date.now(), (S.ts || 0) + 1);   // always moves forward, even if two computers' clocks differ
  persist();
  push();
};

let view = null; // a past day (YYYY-MM-DD) opened read-only from the calendar, or null for today
const viewData = () => {
  const h = (S.hist[view] || {})[S.cur];
  return h ? { solves: h.solves, rounds: h.rounds, round: h.round || h.rounds.length + 1 } : { solves: [], rounds: [], round: 1 };
};

const D = () => view ? viewData() : S.data[S.cur] || (S.data[S.cur] = { solves: [], rounds: [], round: 1 }),
      name = () => curCube().n;

const val = s => s.p === 'D' ? Infinity : s.t + (s.p === 2 ? 2000 : 0);
const fx = x => Number.isNaN(x) ? '–' : F(x, S.set.dec),
      fmtS = s => s.p === 'D' ? 'DNF' : F(val(s), S.set.dec) + (s.p === 2 ? '+' : '');

const arr = v => Float64Array.from(v),
      fmtP = s => fmtS(s) + (s.pb ? ' ★' : '');

// ---- Days: each day starts a fresh session; older days are kept in S.hist (shown in the calendar) ----
const dkey = t => { const d = new Date(t); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };

function rollover() {
  const today = dkey(Date.now());
  if (S.day === today) return false;
  S.hist = S.hist || {};
  let last = 0;
  for (const id in S.data) { const L = S.data[id].solves; if (L.length) last = Math.max(last, L[L.length - 1].d || 0); }
  const key = S.day || (last ? dkey(last) : today);
  let moved = false;
  if (key !== today) {
    for (const id in S.data) {
      const e = S.data[id];
      if (!e.solves.length) continue;
      const h = (S.hist[key] = S.hist[key] || {}), o = h[id];
      h[id] = o ? { solves: o.solves.concat(e.solves), rounds: o.rounds.concat(e.rounds), round: Math.max(o.round || 1, e.round) } : { solves: e.solves, rounds: e.rounds, round: e.round };
      moved = true;
    }
    if (moved) S.data = {};
  }
  S.day = today;
  if (moved) { undoDel = []; trimScr(); histCheck = true; save(); }
  return moved;
}

function dayData(key) {
  const h = { ...(S.hist[key] || {}) };
  if (key === S.day) for (const id in S.data) if (S.data[id].solves.length) h[id] = S.data[id];
  return h;
}

const longDay = k => new Date(k + 'T00:00:00').toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
const dur = ms => { const s = Math.round(ms / 1000), h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60); return (h ? h + 'h ' : '') + (h || m ? m + 'm ' : '') + s % 60 + 's'; };
const cal = { y: 0, m: 0, sel: '' };

function calendar(key) {
  const now = new Date(), today = dkey(now);
  if (key) cal.sel = key;
  if (!cal.sel) { cal.sel = today; cal.y = now.getFullYear(); cal.m = now.getMonth(); }
  const first = new Date(cal.y, cal.m, 1), n = new Date(cal.y, cal.m + 1, 0).getDate();
  let cells = '<span></span>'.repeat(first.getDay());
  for (let i = 1; i <= n; i++) {
    const k = cal.y + '-' + String(cal.m + 1).padStart(2, '0') + '-' + String(i).padStart(2, '0');
    const dd = Object.values(dayData(k)), c = dd.reduce((a, e) => a + e.solves.length, 0), hasPb = dd.some(e => e.solves.some(x => x.pb));
    cells += `<button data-a="calday" data-k="${k}" class="${k === cal.sel ? 'on' : c ? 'has' : ''}${k === today ? ' td' : ''}">${i}${c ? `<small>${c}${hasPb ? ' ★' : ''}</small>` : ''}</button>`;
  }
  const day = dayData(cal.sel), ids = Object.keys(day), tile = (l, x) => `<div><small>${l}</small><b>${x}</b></div>`,
        det = ids.length ? ids.map(id => {
          const e = day[id], v = e.solves.map(val), [b, m, , ba] = stats(arr(v)), tot = v.filter(isFinite).reduce((a, c) => a + c, 0), cn = allCubes().find(c => c.id === id), pbn = e.solves.filter(x => x.pb).length, dnn = e.solves.filter(x => x.p === 'D').length;
          return `<div class="dcard"><h4>${esc(cn ? cn.n : id)}</h4><div class="dtiles">${tile('Solves', e.solves.length)}${tile('Best', fx(b))}${tile('Mean', fx(m))}${tile('Best ao5', fx(ba))}${tile('Time spent', dur(tot))}${pbn ? tile('PBs ★', pbn) : ''}${dnn ? tile('DNFs', dnn) : ''}</div><div class="chips">${e.solves.map((s, i) => `<span><small>${i + 1}</small> ${fmtP(s)}</span>`).join('')}</div></div>`;
        }).join('') : '<p class="lead">No solves this day.</p>',
        long = longDay(cal.sel);
  open(`<h3>Calendar</h3><div class="row"><button data-a="calm" data-d="-1">&lsaquo;</button><b style="flex:1;text-align:center">${first.toLocaleDateString(undefined, { month: 'long', year: 'numeric' })}</b><button data-a="calm" data-d="1">&rsaquo;</button></div><div class="cal">${['S', 'M', 'T', 'W', 'T', 'F', 'S'].map(x => `<span>${x}</span>`).join('')}${cells}</div><div class="row dayhead"><b>${long}</b><span class="sp"></span><button class="on" data-a="openday" data-k="${cal.sel}">${cal.sel === S.day ? 'Go to today' : 'Open this day'}</button></div>${det}`);
}

function applyTheme() {
  const r = document.documentElement.style, s = S.set;
  for (const k of ['bg', 'fg', 'ac', 'rd', 'hd']) r.setProperty('--' + k, s[k]);
  r.setProperty('--rad', s.rad + 'px');
  r.setProperty('--ui', s.ui / 100);
  r.setProperty('--th', s.th + 'vh');
  r.setProperty('--tf', FONTS[s.tf] || 'inherit');
  r.setProperty('--tw', s.tw);
  r.setProperty('--sf', s.sfm ? FONTS.mono : 'inherit');
  document.body.classList.toggle('no-rs', !s.showRs);
  document.body.classList.toggle('no-st', !s.showSt);
  document.body.classList.toggle('no-side', !s.showSide);
  for (const [k, c] of [['showMenu', 'no-menu'], ['showGoal', 'no-goal'], ['showSk', 'no-sk'], ['showWk', 'no-wk'], ['showTl', 'no-tl'], ['showRd', 'no-rd']]) document.body.classList.toggle(c, s[k] === false);
  document.body.classList.toggle('no-parts', ['showMenu', 'showGoal', 'showSk', 'showWk', 'showTl', 'showRd'].every(k => s[k] === false));
  if (window.placeSide) window.placeSide();   // docked bar, or inside the timer area
  if (window.rdSync) window.rdSync();   // the custom rounds scrollbar must follow the layout change
  r.setProperty('--fs', s.fs + 'px');
  r.setProperty('--ss', s.ss + 'px');
  $('#scr').style.display = s.showScr ? '' : 'none';
  const dim = Math.max(0, Math.min(90, s.wallDim ?? 45)), tint = `color-mix(in srgb, ${s.bg} ${dim}%, transparent)`;
  document.documentElement.style.backgroundImage = WALL ? `linear-gradient(${tint}, ${tint}), url("${WALL}")` : '';
  r.setProperty('--cop', Math.max(0, Math.min(100, s.cardOp ?? 72)) + '%');
  if (s.sideOp == null) s.sideOp = s.cardOp ?? 72;   // first time: same look as the other boxes
  r.setProperty('--sop', Math.max(0, Math.min(100, s.sideOp)) + '%');
  document.body.classList.toggle('has-wall', !!WALL);
}

let raf = 0, scr = '', mode = 'idle', holding = false, ready = false, ht, t0 = 0, i0 = 0, pen = 0, b8 = 0, b12 = 0;

const newScr = () => {
  scr = S.set.rnd ? 'Random' : genScr(curCube());
  $('#scr').textContent = view ? '' : S.set.rnd ? 'Random scramble · solves are saved as "Random"' : (scr || '(this cube has no scramble)');
  if (typeof pracUI === 'function') pracUI();   // 3x3 practice modes: case info under the scramble (practice.js)
};

// New scramble, reset timer and message.
const fresh = () => { newScr(); tm.textContent = '0.00'; $('#msg').textContent = ''; render(); };

const volume = () => (S.set.vol ?? 60) / 100;
// connect nodes in a chain: link(a, b, c) = a -> b -> c
const link = (...n) => n.reduce((a, b) => (a.connect(b), b));

function beep(f) {
  if (!S.set.snd) return;
  try {
    const c = new AudioContext(), o = c.createOscillator();
    o.frequency.value = f;
    const g = c.createGain();
    g.gain.value = volume();
    link(o, g, c.destination);
    o.start();
    setTimeout(() => { o.stop(); c.close(); }, 180);
  } catch (e) {}
}

const ORD = ['1st', '2nd', '3rd', '4th', '5th'];

function rstrip(d) {
  const ix = d.solves.map((_, i) => i);
  let I = S.set.auto ? ix.filter(i => d.solves[i].r === d.round) : ix.slice(-5);
  if (S.set.auto && !I.length && d.round > 1) I = ix.filter(i => d.solves[i].r === d.round - 1);
  const L = I.map(i => d.solves[i]);
  let lo = -1, hi = -1;
  if (L.length > 1) {
    const v = L.map(val);
    hi = v.indexOf(Math.max(...v));
    lo = v.indexOf(Math.min(...v));
    if (lo === hi) lo = hi = -1;
  }
  $('#rs').innerHTML = ORD.map((o, i) => {
    const s = L[i], t = s ? fmtP(s) : '–';
    const w = L.length === 5 ? '(' + t + ')' : t;
    return `<div${s ? ` data-a="solve" data-i="${I[i]}" class="pick"` : ''}><small>${o} solve</small><b${i === lo ? ' class="g"' : i === hi ? ' class="r"' : ''}>${i === lo ? '+' + w : i === hi ? '-' + w : t}</b></div>`;
  }).join('');
}

// The list of finished rounds (side column on desktop, Today popup on phones).
function roundsHtml(d, max) {
  const rbest = minOf(d.rounds.map(r => r.res).filter(isFinite));
  return [...d.rounds].reverse().map((r, i, a) => { const p = a[i + 1], dd = p && isFinite(r.res) && isFinite(p.res) ? r.res - p.res : null; return `<div data-a="round" data-n="${r.n}" class="pick" style="cursor:pointer" title="Click to open this round"><b>Round ${r.n}: ${fx(r.res)}${d.rounds.length > 1 && r.res === rbest ? ' ★' : ''}</b> ${r.part ? '(' + r.part + ' of 5 solves)' : '(ao5)'}${dd === null ? '' : ` <span class="${dd <= 0 ? 'g' : 'r'}">${dd <= 0 ? '▼' : '▲'}${ds(dd)}</span>`} · ${r.v.map(esc).join(', ')}</div>`; }).slice(0, max || Infinity).join('');
}

function render() {
  syncMode();
  $('#ev').textContent = name();
  const d = D(), [best, mean, cur, bao] = stats(arr(d.solves.map(val))),
        bx = (l, x) => `<div><small>${l}</small><b>${fx(x)}</b></div>`;
  rstrip(d);
  $('#st').innerHTML = bx('Best', best) + bx('Mean', mean) + bx('Current ao5', cur) + bx('Best ao5', bao) + `<div><small>Round</small><b>${S.set.auto ? d.round + ' · ' + d.solves.filter(x => x.r === d.round).length + '/5' : 'off'}</b></div>`;
  $('#cnt').textContent = name() + ' · ' + plural(d.solves.length, 'solve') + (view ? '' : ' today');
  $('#mini').innerHTML = miniPanel(d);
  $('#dt').textContent = (view ? new Date(view + 'T00:00:00') : new Date()).toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' });
  $('#dt').classList.toggle('on', !!view);
  $('#goal').innerHTML = goalPanel();
  document.body.classList.toggle('view', !!view);
  const vb = $('#vb');
  vb.hidden = !view;
  if (view) {
    vb.innerHTML = `<span>Viewing <b>${longDay(view)}</b> · read-only</span><span class="sp"></span><button data-a="today">Back to today</button>`;
    tm.textContent = d.solves.length ? fmtS(d.solves[d.solves.length - 1]) : '–';
    $('#msg').textContent = 'Past day: you can look, but nothing can be changed.';
  }
  $('#rd').innerHTML = roundsHtml(d);   // all rounds, newest first; the side column scrolls (about 5 rounds are visible at once)
}

// Rebuild finished-round records from the solves, so deleting/restoring a time keeps them correct.
function fixRounds(d) {
  // also repair the current round number, so deleting a time from a finished round reopens that round
  if (!d.solves.length) d.round = 1;
  else {
    const mx = Math.max(0, ...d.solves.map(x => x.r || 0));
    if (mx) d.round = d.solves.filter(x => x.r === mx).length >= 5 ? mx + 1 : mx;
  }
  d.rounds = [];
  for (let n = 1; n < d.round; n++) {
    const rs = d.solves.filter(x => x.r === n);
    if (rs.length === 5) d.rounds.push({ n, res: ao5(arr(rs.map(val))), v: rs.map(fmtS) });
    else if (rs.length) d.rounds.push({ n, res: NaN, v: rs.map(fmtS), part: rs.length }); // a time was deleted: the round stays, with fewer solves
  }
}

let undoDel = []; // deleted times, newest last, so every delete can be undone in turn

// Re-checks everything that is worked out from the solves, after a time is deleted, restored or changed:
// rounds, PB stars and the stored records.
function refix() {
  fixRounds(D());
  repb(S.cur);
  repRec(S.cur);
}

function delSolve(i) {
  if (view) return;
  const d = D(), s = d.solves[i];
  if (!s) return;
  d.solves.splice(i, 1);
  undoDel.push({ ev: S.cur, i, s });
  if (undoDel.length > 50) undoDel.shift();
  refix();
  save();
  render();
  const l = d.solves[d.solves.length - 1];
  tm.textContent = l ? fmtS(l) : '0.00';
  $('#msg').innerHTML = `Deleted ${fmtS(s)} · <button data-a="undo">Undo</button>`;
}

function undoSolve() {
  const u = undoDel.pop();
  if (!u) return;
  S.cur = u.ev;
  const d = D();
  d.solves.splice(Math.min(u.i, d.solves.length), 0, u.s);
  refix();
  save();
  render();
  tm.textContent = fmtS(u.s);
  $('#msg').innerHTML = 'Time restored' + (undoDel.length ? ' · <button data-a="undo">Undo another</button>' : '');
}

const focusUI = () => document.body.classList.toggle('run', S.set.focus && mode !== 'idle');

// ---- Reactions: cheers, comfort, streaks, goals, effects ----
const hist = id => Object.keys(S.hist || {}).sort().map(k => S.hist[k][id]).filter(Boolean),
      pastSolves = id => hist(id).flatMap(x => x.solves),
      pastRounds = id => hist(id).flatMap(x => x.rounds),
      allSolves = id => pastSolves(id).concat((S.data[id] || { solves: [] }).solves),
      sum = o => Object.values(o).reduce((a, e) => a + e.solves.length, 0),
      todayCount = (id = S.cur) => (S.data[id] || { solves: [] }).solves.length,
      cubeDay = (key, id = S.cur) => ((dayData(key) || {})[id] || { solves: [] }).solves.length,
      buzz = ms => { if (S.set.vib && navigator.vibrate) try { navigator.vibrate(ms); } catch (e) {} };

// small helpers
const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'),
      ds = ms => (Math.abs(ms) / 1000).toFixed(S.set.dec === 3 ? 3 : 2),
      plural = (n, w) => n + ' ' + w + (n === 1 ? '' : 's'),
      fill = (s, o) => s.replace(/\{(\w+)\}/g, (_, k) => o[k] ?? ''),
      mn = a => a.length ? a.reduce((x, y) => x + y, 0) / a.length : NaN,
      minOf = a => a.reduce((m, x) => x < m ? x : m, Infinity),
      maxOf = a => a.reduce((m, x) => x > m ? x : m, -Infinity),
      ord = n => n + (['th', 'st', 'nd', 'rd'][(n % 100 >> 3 ^ 1) && n % 10 < 4 ? n % 10 : 0]),
      ago = ms => {
        const m = Math.round(ms / 6e4), h = Math.round(ms / 36e5), d = Math.round(ms / 864e5);
        return m < 2 ? 'about a minute' : m < 90 ? m + ' minutes' : h < 48 ? h + ' hours' : d < 60 ? d + ' days' : Math.round(d / 30) + ' months';
      };

// Trimmed averages like WCA: drop the best and worst 5% (at least one each). Too many DNFs = DNF.
const aoW = (w, n) => {
        const trim = Math.ceil(n * .05), a = Float64Array.from(w).sort();
        let dnf = 0;
        for (let i = n - 1; i >= 0 && a[i] === Infinity; i--) dnf++;
        if (dnf > trim) return Infinity;
        let sum = 0;
        for (let i = trim; i < n - trim; i++) sum += a[i];
        return sum / (n - 2 * trim);
      },
      aoN = (v, n) => v.length < n ? NaN : aoW(v.slice(-n), n),
      rollMin = (v, n) => { let b = Infinity; for (let i = n; i <= v.length; i++) { const x = aoW(v.slice(i - n, i), n); if (x < b) b = x; } return b; };

// Remembers the best average up to a point, so a long history is not rescanned on every solve.
let AOC = {};
function bestAoUpTo(id, v, k, upto) {
  const key = id + '|' + k, c = AOC[key] && AOC[key].n <= upto ? AOC[key] : { n: 0, b: Infinity };
  let b = c.b;
  for (let i = Math.max(c.n + 1, k); i <= upto; i++) { const x = aoW(v.slice(i - k, i), k); if (x < b) b = x; }
  AOC[key] = { n: upto, b };
  return b;
}

// Personal-best stars: rebuilt from the whole history, so deleting or editing a time keeps them correct.
function repb(id) {
  AOC = {};
  histCheck = true;   // this can change the stars on past days
  let b = Infinity, n = 0;
  for (const s of allSolves(id)) {
    const x = val(s);
    if (!isFinite(x)) { delete s.pb; continue; }
    if (n >= 5 && x < b) s.pb = 1; else delete s.pb;
    if (x < b) b = x;
    n++;
  }
}

// Stored records (best run of fast solves, best day streak) are rebuilt from the solves that are left,
// so a deleted time cannot keep a record alive. They can only go down here, never up.
function repRec(id) {
  const rc = recOf(id), pv = [], fin = [];
  let best = 0, pb = Infinity;
  for (const s of allSolves(id)) {
    const v = val(s), ok = isFinite(v), recent = fin.slice(-12), base = recent.length >= 5 ? mn(recent) : 0;
    // same cases as react(): the solve is not a DNF and not a new PB
    if (ok && base && !(fin.length >= 5 && v < pb)) {
      const seq = pv.slice(-20).concat(v);
      let f = 0;
      for (let i = seq.length - 1; i >= 0 && seq[i] < base; i--) f++;
      if (f >= 3 && f > best) best = f;
    }
    pv.push(v);
    if (ok) { fin.push(v); if (v < pb) pb = v; }
  }
  rc.streak = Math.min(rc.streak || 0, best);
  // longest run of days in a row with at least one solve on THIS cube
  const have = new Set(Object.keys(S.hist || {}).filter(k => (S.hist[k][id] || { solves: [] }).solves.length));
  if (todayCount(id)) have.add(S.day || dkey(Date.now()));
  let run = 0, top = 0;
  for (const k of [...have].sort()) {
    const p = new Date(k + 'T00:00:00');
    p.setDate(p.getDate() - 1);
    run = have.has(dkey(p)) ? run + 1 : 1;
    if (run > top) top = run;
  }
  rc.days = rc.days == null ? top : Math.min(rc.days, top);
}

function migrate() {
  S.rec = S.rec || {};
  S.rec.c = S.rec.c || {};
  AOC = {};
  for (const id in S.data) if (S.data[id].solves.some(x => x.r)) fixRounds(S.data[id]);
  if (!S.rec.v) { for (const c of allCubes()) repb(c.id); S.rec.v = 1; }
}

const recOf = id => { S.rec = S.rec || {}; S.rec.c = S.rec.c || {}; return S.rec.c[id] || (S.rec.c[id] = {}); };

// ---- Per-cube knowledge: sub-X targets, greetings, flavor lines and a tip for slow solves ----
const MILES = [1, 10, 25, 50, 100, 150, 200, 250, 300, 400, 500, 750, 1000, 1500, 2000, 2500, 3000, 4000, 5000, 7500, 10000],
      DSM = [3, 5, 7, 10, 14, 21, 30, 50, 75, 100, 150, 200, 365],
      HRS = [1, 5, 10, 25, 50, 100, 250, 500, 1000],
      BASE = {
        subs: [],
        hi: ["Let's go!", 'Ready when you are!', 'Time to turn some cubes!'],
        fl: ['Every solve builds your look-ahead and your fingers.', 'Practice like this is how times drop.', 'Showing up every day is what makes people fast.'],
        tip: ''
      },
      PROF = {
        '2': { subs: [15, 10, 8, 6, 5, 4, 3, 2.5, 2, 1.5, 1], hi: ['Tiny cube, big speed!', "Let's twist!"], tip: 'On a 2x2 a slow solve usually means an awkward last layer. Spend a little more of your inspection planning the first layer.' },
        '3': { subs: [60, 45, 30, 25, 20, 18, 15, 13, 12, 11, 10, 9, 8, 7, 6, 5], hi: ['Time to turn some layers!', "Let's go!"], tip: 'A slow 3x3 solve is often one long pause. Next time notice where you stopped to think; that is the step to practice.' },
        oh: { subs: [90, 60, 45, 40, 35, 30, 25, 20, 18, 15, 12, 10], hi: ['One hand, full focus!', "Let's go, lefty or righty!"], tip: 'One-handed solves swing more than two-handed ones, mostly from regrips. Smooth, slow turns usually beat fast, jerky ones.' },
        bld: { subs: [600, 420, 300, 240, 180, 150, 120, 90, 75, 60, 50, 40, 30], hi: ['Memorise, breathe, solve. Blindfold on!', 'Calm mind, clear memo!'], tip: 'A slow blindfolded solve is usually a long memo. A clear story or picture for each pair of pieces helps more than rushing.' },
        '4': { subs: [240, 180, 150, 120, 100, 90, 80, 70, 60, 50, 45, 40, 35, 30], hi: ['Centers, edges, then the fun part!'], tip: 'On a 4x4 a slow solve is often a long edge-pairing stage or a parity case. Both vary a lot, so do not worry.' },
        '5': { subs: [360, 300, 240, 180, 150, 120, 100, 90, 80, 70, 60], hi: ['Big cube, big patience. Go!'], tip: 'Big cubes have many more places to lose time, so times swing more. Keep your turns smooth and your pairing steady.' },
        '6': { subs: [600, 480, 420, 360, 300, 240, 210, 180, 150, 120], hi: ['Big cube, big patience. Go!'], tip: 'A 6x6 solve has a lot of steps, so one slow stage is normal. Smooth turning matters more than speed.' },
        '7': { subs: [900, 720, 600, 480, 420, 360, 300, 240, 180], hi: ['Big cube, big patience. Go!'], tip: 'A 7x7 solve has a lot of steps, so one slow stage is normal. Smooth turning matters more than speed.' },
        pyra: { subs: [60, 40, 30, 20, 15, 12, 10, 8, 7, 6, 5, 4, 3], hi: ['Pyraminx time, sharp and quick!'], tip: 'Pyraminx times swing a lot because one awkward last-layer case can double the time.' },
        skewb: { subs: [60, 40, 30, 20, 15, 12, 10, 8, 7, 6, 5, 4, 3], hi: ['Skewb time, short and sharp!'], tip: 'Skewb solves are short, so one bad case stands out. Practice the rare cases to even it out.' },
        mega: { subs: [600, 480, 360, 300, 240, 180, 150, 120, 100, 90, 80, 70, 60, 50, 45, 40, 30], hi: ['Twelve faces, one calm mind!'], tip: 'Megaminx has many moves, so small pauses add up. Aim for a smooth, steady rhythm.' }
      },
      profile = c => ({ ...BASE, ...(PROF[c.id === 'oh' || c.id === 'bld' ? c.id : c.t] || {}) });

// ---- Message pools. {t} time, {cn} cube, {gap} seconds gained, {old} old record, {pct} percent, {dif} seconds off average, {avg} average, {off} seconds off PB, {best} PB ----
const PBL = {
  std: [
    `🎉 CONGRATULATIONS! NEW PERSONAL BEST! {t} is {gap}s faster than your old record of {old}. Absolutely incredible!`,
    `🏆 Congratulations, {t} is a PB! {gap}s quicker than ever before ({pct}% faster). Be so proud!`,
    `🔥 PERSONAL BEST!!! Congratulations on {t} on {cn}. All that practice just paid off, amazing!`,
    `⚡ Congratulations, new record: {t}! You just knocked {gap}s off your best. You are on fire!`
  ],
  big: [
    `🚀 CONGRATULATIONS, HUGE PB! {t}! You smashed your old record of {old} by {gap}s ({pct}%). Unreal!`,
    `🤯 {t}?! Congratulations, that is a MASSIVE {gap}s improvement on your record. Take a bow!`,
    `💥 BOOM! {t}! Congratulations, your old best of {old} just got crushed by {pct}%!`
  ],
  tiny: [
    `😮 Congratulations, NEW PB by just {gap}s: {t}! Every hundredth counts, and that one is yours!`,
    `✨ Congratulations, a razor-thin PB: {t}, only {gap}s faster than before. A record is a record! 🏆`
  ]
};

const SLOW = {
  vbad2: [
    [`Whoa, {t}?! That solve took a long vacation 🏖️😄 It happens to everyone. Shake it off, the next one is yours!`,
     `{t}… you and the cube clearly had a disagreement 😅 No problem! One wild solve does not erase all the fast ones.`,
     `That was a collector's edition solve ({t}) 🐢 Rare, funny, and already forgotten. Reset and go!`],
    [`{t} was a very tough one. It happens to every cuber, and one solve says nothing about how good you are. Breathe and go again 💙`,
     `A rough one, and that is completely okay. Your real progress shows in your averages, not in single solves 💙`]
  ],
  vbad: [
    [`Whoa, {t}?! That one took the scenic route 🐢😄 Don't worry, everyone has solves like this. Reset and crush the next one!`,
     `{t}… the cube said "not today" 😅 It's totally okay! One slow solve doesn't erase all your fast ones.`,
     `Plot twist: that solve was a speed-limit zone 🚧😂 Breathe, you are still improving, and the next one's yours!`,
     `{t}: the cube is just keeping you humble 😌 That was {dif}s over your average, nothing a fresh scramble can't fix!`],
    [`{t} was a tough one, {dif}s slower than your average of {avg}. It happens to every cuber, and one solve does not define you. Breathe and go again 💙`,
     `A slow one, and that is completely fine. Your real progress shows in the average 💙`,
     `That one fought back ({t}). Everyone has solves like this. Reset your hands and go again 💙`]
  ],
  bad2: [
    [`{t} is {dif}s slower than your average of {avg}. Totally normal! Breathe and go again 💙`,
     `A slower one ({t}). Your average of {avg} is the real story, so keep going 💪`,
     `Not your best, but even the best cubers have off solves. Fresh scramble, fresh start 💙`]
  ],
  bad1: [
    [`A bit slower than your usual ({dif}s over your {avg} average). Totally normal! Breathe and go again 💙`,
     `Not your fastest, but your average of {avg} is the real story. Keep going!`,
     `Everybody has slower solves. Shake it off, the next scramble is fresh 💪`]
  ]
};

const GOOD = {
  near: [
    `So close! {t} is only {off}s off your PB of {best} 😮 The next one could be the one!`,
    `⚡ {t}, just {off}s away from your record! Keep this energy.`,
    `Almost a PB! Only {off}s from {best}. You are right at the edge 🔥`
  ],
  good3: [
    `🚀 Wow, {t} is way faster than usual, {dif}s under your {avg} average!`,
    `🔥 That was a fast one! {dif}s quicker than your average. Are you warmed up?`
  ],
  good2: [
    `Faster than your usual! 🔥 {t} beats your {avg} average by {dif}s.`,
    `⚡ Quick! {dif}s under your average of {avg}.`
  ],
  good1: [
    `Nice one, {t} is under your average ⚡ ({dif}s faster).`,
    `Smooth! That one was quicker than normal 👏`,
    `Faster than your usual, keep it rolling 🔥`
  ],
  ok: ['Solid solve. 👍', 'Nice and steady.', 'Clean solve, keep the rhythm.', 'Saved. Next scramble when you are ready.']
};

const DNFL = {
  fun: ['DNF 😬 The cube won that round. It happens to everybody, so shake it off and go again!', 'A DNF! Even world record holders get them. Onto the next one 💪', 'The cube said no. Fair enough. Next scramble, fresh start! 🧊'],
  kind: ['A DNF happens to every cuber. It is only one solve. Breathe and go again 💙', 'Not this one, but the next could be a great one. You are doing fine 💙', 'That one did not count, but you lost nothing. Reset when you are ready 💙'],
  two: [`Two DNFs in a row 😬 Take a breath, shake out your hands and reset. The next one is a fresh start!`, `Two in a row is rough, but it is just a bad patch. Shake out your hands, breathe, and go again 💙`],
  insp: '⏱️ Inspection ran past 17 s, which is an automatic DNF by the rules. Next time aim to start around 12 to 13 s; that leaves a calm buffer and no penalty.',
  tip: 'Tip: before you stop the timer, take half a second to check that every face is solved.'
};

// ---- Sounds and effects ----
function jingle(notes, step = 0.11, len = 0.16) {
  const vol = volume() * 0.6;
  if (!S.set.sfx || vol <= 0) return;
  try {
    const c = new AudioContext();
    notes.forEach((n, i) => {
      const fs = [].concat(n), t = c.currentTime + i * step;
      fs.forEach(f => {
        const o = c.createOscillator(), g = c.createGain();
        o.type = 'triangle';
        o.frequency.value = f;
        g.gain.setValueAtTime(vol / Math.sqrt(fs.length), t);
        g.gain.exponentialRampToValueAtTime(0.001, t + len);
        link(o, g, c.destination);
        o.start(t);
        o.stop(t + len + 0.02);
      });
    });
    setTimeout(() => c.close(), (notes.length * step + len + 0.3) * 1000);
  } catch (e) {}
}

// ---- Joyful PB music: melody + chords + bass + drums, all synthesized (no audio files needed) ----
const hz = m => 440 * 2 ** ((m - 69) / 12);
// bpm, one chord root per bar (major chords; the last bar is a held finish), melody as [midi note, beats]
const TUNES = [
  { bpm: 172, ch: [48, 43, 41, 43, 48], mel: [
    [67, .5], [72, .5], [76, .5], [79, .5], [84, 1], [79, 1],
    [86, 1], [83, .5], [79, .5], [83, 1], [86, 1],
    [81, .5], [84, .5], [89, 1], [88, .5], [86, .5], [84, 1],
    [83, .5], [86, .5], [91, 1], [88, .5], [86, .5], [83, .5], [79, .5],
    [84, 3]
  ] },
  { bpm: 164, ch: [43, 50, 48, 50, 43], mel: [
    [74, .5], [79, .5], [83, .5], [86, .5], [91, 1], [86, 1],
    [90, 1], [88, .5], [86, .5], [85, 1], [88, 1],
    [88, .5], [86, .5], [84, 1], [79, .5], [84, .5], [88, 1],
    [90, .5], [93, .5], [90, 1], [88, .5], [86, .5], [85, .5], [86, .5],
    [91, 3]
  ] }
];

// Plays a ~6 second happy tune. Returns false when music is off, so the caller can fall back to the short jingle.
function pbMusic(big) {
  const vol = volume() * 0.5;
  if (!S.set.sfx || S.set.pbm === false || vol <= 0) return false;
  try {
    const T = pk(TUNES), c = new AudioContext(), b = 60 / T.bpm, t0 = c.currentTime + 0.05;
    if (c.state === 'suspended') c.resume();
    const out = c.createGain(), comp = c.createDynamicsCompressor(), dly = c.createDelay(), fb = c.createGain(), wet = c.createGain();
    out.gain.value = vol;
    dly.delayTime.value = b * 0.75;
    fb.gain.value = 0.22;
    wet.gain.value = 0.28;
    link(out, comp);
    link(out, dly, fb, dly);
    link(dly, wet, comp, c.destination);
    const nb = c.createBuffer(1, Math.round(c.sampleRate * 0.3), c.sampleRate), nd = nb.getChannelData(0);
    for (let i = 0; i < nd.length; i++) nd[i] = Math.random() * 2 - 1;

    // one pitched note; s = how much volume is kept halfway (low = plucky, high = sustained)
    const note = (m, t, d, g, type = 'triangle', s = 0.3) => {
      const o = c.createOscillator(), e = c.createGain();
      o.type = type;
      o.frequency.value = hz(m);
      e.gain.setValueAtTime(0.0001, t);
      e.gain.exponentialRampToValueAtTime(g, t + 0.015);
      e.gain.exponentialRampToValueAtTime(g * s, t + d * 0.6);
      e.gain.exponentialRampToValueAtTime(0.0001, t + d);
      link(o, e, out);
      o.start(t);
      o.stop(t + d + 0.03);
    };
    const noise = (t, d, f, type, g) => {
      const s = c.createBufferSource(), fl = c.createBiquadFilter(), e = c.createGain();
      s.buffer = nb;
      s.loop = true;
      fl.type = type;
      fl.frequency.value = f;
      e.gain.setValueAtTime(g, t);
      e.gain.exponentialRampToValueAtTime(0.0001, t + d);
      link(s, fl, e, out);
      s.start(t);
      s.stop(t + d + 0.02);
    };
    const kick = t => {
      const o = c.createOscillator(), e = c.createGain();
      o.frequency.setValueAtTime(150, t);
      o.frequency.exponentialRampToValueAtTime(45, t + 0.12);
      e.gain.setValueAtTime(0.7, t);
      e.gain.exponentialRampToValueAtTime(0.0001, t + 0.16);
      link(o, e, out);
      o.start(t);
      o.stop(t + 0.2);
    };

    // accompaniment: kick + bass on beats 1 and 3, chord stabs + clap on 2 and 4, hi-hats on every half beat
    const last = T.ch.length - 1;
    T.ch.forEach((r, i) => {
      const tb = t0 + i * 4 * b, pad = [r + 12, r + 16, r + 19];
      if (i === last) {
        pad.forEach(m => note(m, tb, b * 3.2, 0.16, 'triangle', 0.8));
        note(r, tb, b * 3.2, 0.32, 'triangle', 0.8);
        kick(tb);
        noise(tb, big ? 1.2 : 0.6, 5000, 'highpass', big ? 0.35 : 0.2);
        return;
      }
      for (let j = 0; j < 4; j++) {
        const t = tb + j * b;
        if (j % 2 === 0) { kick(t); note(j ? r + 7 : r, t, b * 1.8, 0.34); }
        else { pad.forEach(m => note(m, t, b * 0.8, 0.05, 'square')); noise(t, 0.1, 1800, 'bandpass', 0.35); }
        noise(t, 0.035, 7000, 'highpass', 0.12);
        noise(t + b / 2, 0.035, 7000, 'highpass', 0.18);
      }
    });

    // melody (a sparkly octave on top; a big PB adds a brighter second octave layer)
    let t = t0;
    T.mel.forEach(([m, d], k) => {
      const fin = k === T.mel.length - 1, len = d * b * (fin ? 1.1 : 1.05);
      note(m, t, len, 0.3, 'triangle', fin ? 0.8 : 0.3);
      note(m + 12, t, len, 0.08, 'sine', fin ? 0.8 : 0.3);
      if (big) note(m + 12, t, len, 0.1, 'triangle', fin ? 0.8 : 0.3);
      t += d * b;
    });
    setTimeout(() => c.close(), (19 * b + 2.5) * 1000);
    return true;
  } catch (e) { return false; }
}

// mode 'c' = burst from the middle, 'lr' = two cannons from the lower corners
function confetti(n = 150, mode = 'c') {
  if (!S.set.fx || n <= 0 || matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  const dpr = Math.min(window.devicePixelRatio || 1, 2), W = innerWidth, H = innerHeight, cv = document.createElement('canvas'), x = cv.getContext('2d'),
        cols = ['#f1c40f', '#e74c3c', '#2ecc71', '#3498db', '#9b59b6', '#ff9f43', '#ff6b9d'];
  cv.style.cssText = 'position:fixed;inset:0;width:100%;height:100%;pointer-events:none;z-index:99';
  cv.setAttribute('aria-hidden', 'true');
  cv.width = W * dpr;
  cv.height = H * dpr;
  x.scale(dpr, dpr);
  document.documentElement.appendChild(cv);
  const mk = (ox, oy, ang, spread) => {
    const a = ang + (Math.random() - .5) * spread, sp = 7 + Math.random() * 13;
    return { x: ox, y: oy, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, s: 6 + Math.random() * 6, r: Math.random() * 6, vr: (Math.random() - .5) * .5, c: pk(cols), k: R(3) };
  };
  const P = Array.from({ length: n }, (_, i) => mode === 'lr'
    ? (i % 2 ? mk(W, H * .85, -Math.PI * .72, .8) : mk(0, H * .85, -Math.PI * .28, .8))
    : mk(W / 2 + (Math.random() - .5) * 240, H * .45, -Math.PI / 2, Math.PI * 1.1));
  let f = 0;
  (function step() {
    x.clearRect(0, 0, W, H);
    x.globalAlpha = f > 100 ? Math.max(0, (140 - f) / 40) : 1;
    P.forEach(p => {
      p.vx *= .995;
      p.vy = p.vy * .995 + .35;
      p.x += p.vx;
      p.y += p.vy;
      p.r += p.vr;
      x.save();
      x.translate(p.x, p.y);
      x.rotate(p.r);
      x.fillStyle = p.c;
      if (p.k === 1) { x.beginPath(); x.arc(0, 0, p.s / 2.2, 0, 7); x.fill(); }
      else if (p.k === 2) x.fillRect(-p.s, -1.5, p.s * 2, 3);
      else x.fillRect(-p.s / 2, -p.s / 3, p.s, p.s / 1.5);
      x.restore();
    });
    if (++f < 140) requestAnimationFrame(step); else cv.remove();
  })();
}

function flash(el, cls, ms) {
  if (!el || !S.set.fx) return;
  el.classList.remove(cls);
  void el.offsetWidth;
  el.classList.add(cls);
  setTimeout(() => el.classList.remove(cls), ms);
}

// kind: pb, milestone, goal, good, bad, vbad, dnf. x.big = a huge PB or a first sub-X. Strength setting scales the confetti.
function celebrate(kind, x = {}) {
  const k = (S.set.fxi ?? 2) / 2, big = !!x.big, tz = $('#tz');
  if (kind === 'pb') {
    confetti(Math.round((big ? 220 : 130) * k), big ? 'lr' : 'c');
    if (big) setTimeout(() => confetti(Math.round(110 * k), 'c'), 650);
    if (!pbMusic(big)) jingle(big ? [523, 659, 784, [1047, 523], 1319, [1568, 784, 392]] : [523, 659, 784, 1047, 1319], big ? 0.11 : 0.1, 0.24);
    buzz(big ? [60, 40, 60, 40, 60, 40, 220] : [60, 40, 60, 40, 140]);
    flash(tm, 'pbflash', 1600);
    flash(tz, 'pbglow', 1900);
  } else if (kind === 'milestone') {
    confetti(Math.round(110 * k), 'c');
    jingle([659, 784, 988, 1319], 0.1, 0.2);
    buzz([40, 30, 40, 30, 120]);
    flash(tz, 'cheer', 1500);
  } else if (kind === 'goal') {
    confetti(Math.round(150 * k), 'lr');
    jingle([523, 659, 784, 1047, 784, 1047], 0.1, 0.2);
    buzz([50, 30, 50, 30, 150]);
    flash(tz, 'cheer', 1500);
    flash($('#goal'), 'flash', 1500);
  } else if (kind === 'good') {
    jingle(x.fast >= 3 ? [659, 784, 988].slice(0, Math.min(3, x.fast - 1)).concat(1175) : [659, 784], 0.09, 0.14);
    buzz(25);
  } else if (kind === 'bad') {
    jingle([392, 330], 0.14, 0.22);
    buzz(60);
  } else if (kind === 'vbad') {
    jingle(S.set.tone === 'fun' ? [392, 349, 311, 262] : [392, 349], 0.16, 0.26);
    buzz(80);
  } else if (kind === 'dnf') {
    jingle([330, 262], 0.15, 0.25);
    buzz(100);
  }
}

const rk = k => ({ pb: 5, milestone: 4, goal: 3 }[k] || 0),
      bump = (x, k) => { if (rk(k) > rk(x.kind)) x.kind = k; };

// Daily goal: quarter, half, three quarters, one to go, reached, and bonus solves after that.
function goalEvent(x, after, best) {
  const g = S.set.goal;
  if (!g) return;
  const m = {};
  if (g >= 8) m[Math.ceil(g * .25)] = ['goalp', `📈 A quarter of the way to your daily goal (${after}/${g}). Nice start!`];
  m[Math.ceil(g * .5)] = ['goalp', `📈 Halfway to your daily goal (${after}/${g}). Keep the rhythm!`];
  m[Math.ceil(g * .75)] = ['goalp', `📈 Three quarters done (${after}/${g}). The finish line is in sight!`];
  if (g >= 4) m[g - 1] = ['goalp', `🎯 One more solve to hit your daily goal!`];
  m[g] = ['goal', `🎯 DAILY GOAL REACHED: ${g} solves today!${isFinite(best) ? ` Best of today so far: ${fx(best)}.` : ''} Great work!`];
  let hit = m[after];
  if (after > g && after % g === 0) hit = ['goal', `🌟 ${after / g}× your daily goal (${after} solves)! Bonus territory!`];
  else if (after > g && (after - g) % 10 === 0 && !hit) hit = ['goalp', `💪 ${after - g} bonus solves past your goal.`];
  if (hit) {
    x.events.push({ k: hit[0], text: hit[1] });
    if (hit[0] === 'goal') bump(x, 'goal');
  }
}

// Looks at one new solve (before it is stored) and builds the whole reaction: headline, number chips, events and tips.
function react(s, why) {
  S.rec = S.rec || {};
  const cube = curCube(), P = profile(cube), cn = esc(cube.n), e = D(), tone = S.set.tone, fun = tone === 'fun',
        prior = allSolves(S.cur), pv = prior.map(val), fin = pv.filter(isFinite), v = val(s), ok = isFinite(v), t = fmtS(s),
        prevBest = minOf(fin), isPB = ok && fin.length >= 5 && v < prevBest,
        recent = fin.slice(-12), base = recent.length >= 5 ? mn(recent) : 0,
        r = base && ok ? v / base : 0, diff = r ? v - base : 0, n = prior.length + 1, nt = e.solves.length + 1,
        tv = e.solves.map(val).filter(isFinite), dayFirst = todayCount() === 0,
        x = { head: '', hk: 'ok', kind: 'ok', chips: [], events: [], pre: [], tip: '', pb: isPB, big: false, fast: 0 };
  if (isPB) s.pb = 1;
  if (tone === 'off') { x.head = isPB ? `🏆 Congratulations! New personal best: ${t}!` : 'Solve saved'; x.hk = x.kind = isPB && pbOn('pbS') ? 'pb' : ''; return x; }

  if (isPB) {
    // ---- a new personal best ----
    const g = prevBest - v, gap = ds(g), pct = (g / prevBest * 100).toFixed(1), o = { t, cn, gap, pct, old: fx(prevBest) },
          tier = g >= 1000 || g / prevBest >= .04 ? 'big' : g < 100 ? 'tiny' : 'std',
          sub = P.subs.filter(y => v < y * 1000 && prevBest >= y * 1000).pop(), nxt = P.subs.find(y => v >= y * 1000),
          last = prior[prior.length - 1], k = e.solves.filter(y => y.pb).length + 1, held = [...prior].reverse().find(y => val(y) === prevBest);
    x.hk = x.kind = pbOn('pbS') ? 'pb' : 'ok';
    x.big = pbOn('pbS') && (tier === 'big' || !!sub);
    x.head = fill(pk(PBL[tier]), o) + (last && last.pb ? ' Back-to-back PBs!! 🙌' : '') + (sub ? ` 🥇 That is your FIRST sub-${sub} on ${cn}!` : '');
    x.chips.push(`old record ${fx(prevBest)}`, `−${gap}s (${pct}% faster)`);
    if (held && held.d) x.chips.push(`old PB stood for ${ago(Date.now() - held.d)}`);
    if (k > 1) x.chips.push(`PB #${k} today`);
    x.chips.push(`solve #${n}`);
    if (nxt) x.chips.push(`next goal: sub-${nxt} (${ds(Math.max(v - nxt * 1000, 10))}s to go)`);
  } else if (!ok) {
    // ---- a DNF ----
    const dn = e.solves.filter(y => y.p === 'D').length + 1, rate = Math.round(dn / nt * 100), had = prior.some(y => y.p === 'D'),
          two = prior.length && prior[prior.length - 1].p === 'D';
    let clean = 0;
    for (let i = prior.length - 1; i >= 0 && prior[i].p !== 'D'; i--) clean++;
    x.hk = x.kind = 'dnf';
    x.head = why === 'insp' ? DNFL.insp : two ? pk(DNFL.two.slice(fun ? 0 : 1, fun ? 1 : 2)) : pk(fun ? DNFL.fun : DNFL.kind);
    x.chips.push(`DNFs today: ${dn} of ${nt} (${rate}%)`);
    if (prior.length && !had) x.chips.push(`first DNF in ${plural(clean, 'solve')}`);
    else if (clean >= 10) x.chips.push(`clean streak of ${clean} solves ended`);
    if (why !== 'insp') x.tip = DNFL.tip;
  } else {
    // ---- a normal finished solve: compare it with the recent average ----
    const rel = !r ? '' : Math.abs(diff) < 50 ? 'right on your average' : `${ds(diff)}s ${diff < 0 ? 'faster' : 'slower'} than your average`,
          o = { t, cn, dif: ds(diff), avg: fx(base), off: ds(v - prevBest), best: fx(prevBest) },
          rank = tv.filter(y => y < v).length + 1, pct = fin.length >= 20 ? Math.round(fin.filter(y => y > v).length / fin.length * 100) : -1,
          seq = pv.slice(-20).concat(v), near = fin.length >= 10 && v <= prevBest * 1.03, say = a => fill(pk(a), o), tm2 = mn(tv.concat(v));
    let slow = 0, fast = 0;
    if (base) {
      for (let i = seq.length - 1; i >= 0 && seq[i] > base * 1.1; i--) slow++;
      for (let i = seq.length - 1; i >= 0 && seq[i] < base; i--) fast++;
    }
    x.fast = fast;
    if (r >= 1.2) {
      const tier = r >= 2.5 ? 'vbad2' : r >= 1.6 ? 'vbad' : r >= 1.4 ? 'bad2' : 'bad1', pool = SLOW[tier];
      x.hk = x.kind = tier.startsWith('vbad') ? 'vbad' : 'bad';
      x.head = say(pool[fun ? 0 : Math.min(1, pool.length - 1)]);
      if (tv.length >= 7 && slow < 2 && v > maxOf(tv)) x.head += fun ? ' That is your slowest of today, so from here every solve is an upgrade 😄' : ' It is just the slowest one of today. The rest of your session has been solid 💙';
      if (x.kind === 'vbad' || slow >= 2) x.tip = P.tip;
    } else if (near) {
      x.hk = x.kind = 'good';
      x.head = say(GOOD.near);
    } else if (r && r <= .9) {
      x.hk = x.kind = 'good';
      x.head = say(GOOD[r <= .7 ? 'good3' : r <= .8 ? 'good2' : 'good1']);
    } else {
      x.head = pk(GOOD.ok) + (rel ? ` It was ${rel}.` : '');
    }
    const slowOne = r >= 1.2;
    if (s.p === 2) x.chips.push('includes +2 (inspection past 15 s)');
    if (base) x.chips.push(`${diff < 0 ? '−' : '+'}${ds(diff)}s vs avg of last ${recent.length} (${fx(base)})`);
    else x.chips.push(`averages and PBs unlock after 5 solves (${Math.min(5, fin.length + 1)}/5)`);
    if (slowOne) {
      // for a slow solve show the bigger picture, not a scoreboard
      if (tv.length) x.chips.push(`best of today ${fx(minOf(tv))}`);
      x.chips.push(`overall mean ${fx(mn(fin))}`);
    } else {
      if (isFinite(prevBest) && fin.length >= 5) x.chips.push(`${ds(v - prevBest)}s off your PB (${fx(prevBest)})`);
      if (tv.length >= 2) x.chips.push(`#${rank} of ${tv.length + 1} today`);
      if (pct >= 50) x.chips.push(`faster than ${pct}% of your ${fin.length} solves`);
    }
    if (tv.length >= 2) x.chips.push(`today's mean ${fx(tm2)}`);
    x.chips = x.chips.slice(0, 5);

    // streaks, comebacks and a gentle nudge to rest
    const rc = recOf(S.cur), prev = pv[pv.length - 1];
    if (fast >= 3) {
      let tx = `${fast >= 10 ? '🔥🔥🔥' : fast >= 5 ? '🔥🔥' : '🔥'} ${fast} in a row faster than your average!`;
      if (fast > (rc.streak || 0)) {
        if ((rc.streak || 0) >= 3) tx += ` New personal streak record (the old one was ${rc.streak})!`;
        rc.streak = fast;
      }
      x.events.push({ k: 'streak', text: tx });
    } else if (prev && isFinite(prev) && base && prev / base >= 1.2 && r <= .95) {
      x.events.push({ k: 'streak', text: `Bounce-back! 💪 From ${fx(prev)} to ${t}, that is ${ds(prev - v)}s better.` });
    }
    if (S.set.brk && (slow === 3 || slow === 6)) x.events.push({ k: 'tip', text: `☕ ${plural(slow, 'slower solve')} in a row. That is usually tired hands or a rushed pace. A minute off the cube and a quick stretch often resets it.` });
  }

  // ---- opening line: greeting on the first solve of the day, a note on the first solve of each cube ----
  if (dayFirst) {
    const hr = new Date().getHours(), dsn = streak() + 1, y = new Date(),
          ysum = (y.setDate(y.getDate() - 1), cubeDay(dkey(y))),
          last = Object.keys(S.hist).filter(k => k < S.day && (S.hist[k][S.cur] || { solves: [] }).solves.length).sort().pop(),
          away = last ? Math.round((new Date(S.day) - new Date(last)) / 864e5) : 0, rc = recOf(S.cur).days || 0;
    x.pre.push(hr < 5 ? 'Burning the midnight oil? 🌙' : hr < 12 ? 'Good morning! ☀️' : hr < 17 ? 'Good afternoon! 🌤️' : hr < 22 ? 'Good evening! 🌆' : 'Late-night session! 🌙', pk(P.hi));
    if (away >= 3) x.pre.splice(1, 0, `Welcome back, it has been ${away} days`);
    if (dsn >= 2) x.pre.push(`🔥 Day ${dsn} of your streak`);
    if (ysum) x.pre.push(`Yesterday: ${plural(ysum, 'solve')}`);
    if (dsn > rc) recOf(S.cur).days = dsn;
    if (DSM.includes(dsn)) {
      x.events.push({ k: 'milestone', text: `🔥 ${dsn}-day streak! ${dsn} days in a row of cubing.${dsn > rc && rc >= 2 ? ' That is your longest streak yet!' : ''}` });
      bump(x, 'milestone');
    }
  } else if (nt === 1) {
    x.pre.push(`First ${cn} solve today. ${pk(P.hi)}`);
  }

  // ---- milestones: solve count, hours spent ----
  const fin2 = ok ? fin.concat(v) : fin;
  if (MILES.includes(n)) {
    let tx = n === 1 ? `👋 That was your very first ${cn} solve here. Welcome, and have fun!` : `🎖️ That was your ${ord(n)} ${cn} solve! ${pk(P.fl)}`;
    if (n >= 50 && fin2.length >= 50) {
      const a = mn(fin2.slice(0, 25)), b = mn(fin2.slice(-25));
      tx += a - b > 500 ? ` Your latest 25 average ${fx(b)}, which is ${ds(a - b)}s faster than your first 25 (${fx(a)}). Real progress!` : ` Your first 25 averaged ${fx(a)} and your latest 25 average ${fx(b)}. Keep building!`;
    } else if (n >= 10 && fin2.length) tx += ` Mean of all of them: ${fx(mn(fin2))}.`;
    x.events.push({ k: 'milestone', text: tx });
    bump(x, 'milestone');
  }
  const before = prior.reduce((a, y) => a + (y.t || 0), 0), hh = HRS.find(h => before < h * 36e5 && before + (s.t || 0) >= h * 36e5);
  if (hh) {
    x.events.push({ k: 'milestone', text: `⏱️ You have now spent ${plural(hh, 'hour')} solving ${cn}!` });
    bump(x, 'milestone');
  }

  goalEvent(x, todayCount() + 1, minOf(ok ? tv.concat(v) : tv));
  return x;
}

// Draws a reaction: opening line, headline, number chips, events and a tip. "Short" detail keeps only the headline and events.
function rx(x) {
  const full = S.set.det !== 'short';
  if (!x.head && !x.events.length) return '';
  let h = '<div class="rx">';
  if (x.pre.length) h += `<div class="rx-g">${x.pre.slice(0, full ? 5 : 1).join(' · ')}</div>`;
  h += `<div class="rx-h ${x.hk}">${x.head}</div>`;
  if (full && x.chips.length) h += `<div class="rx-c">${x.chips.map(c => `<span>${c}</span>`).join('')}</div>`;
  h += x.events.map(ev => `<div class="rx-e ${ev.k}">${ev.text}</div>`).join('');
  if (full && x.tip) h += `<div class="rx-t">${x.tip}</div>`;
  return h + '</div>';
}

const streak = (id = S.cur) => {
  const days = new Set(Object.keys(S.hist || {}).filter(k => (S.hist[k][id] || { solves: [] }).solves.length));
  if (todayCount(id)) days.add(S.day || dkey(Date.now()));
  let n = 0;
  const d = new Date();
  if (!days.has(dkey(d))) d.setDate(d.getDate() - 1);
  while (days.has(dkey(d))) { n++; d.setDate(d.getDate() - 1); }
  return n;
};

// Small summary in the top right corner on phones and tablets: solves today + daily goal bar.
function miniPanel(d) {
  const gl = S.set.goal, key = view || S.day || dkey(Date.now()), gc = cubeDay(key), pc = gl ? Math.min(100, Math.round(gc / gl * 100)) : 0;
  return `<b>${plural(d.solves.length, 'solve')}${view ? '' : ' today'}</b>` +
    (gl ? `<div class="gbar"><i style="width:${pc}%"></i></div><small>${gc} / ${gl} · ${pc}%${gc >= gl ? ' ✓' : ''}</small>` : '') +
    `<div class="mx">${weekHtml(key)}${tilesHtml()}</div>`;
}

// Opens a day (same as "Open this day" in the calendar): today = normal mode, any other day = read-only view.
function openDay(k) {
  if (!k) return;
  view = k === S.day ? null : k;
  dl.close();
  fresh();
}

// Last 7 days as small bars (goal reached = green). The week always ends today, so the bars stay put when you click one;
// the day you are looking at is marked (blue letter). Click a bar to open that day.
function weekHtml(key) {
  const gl = S.set.goal, cnt = k => cubeDay(k), days = [], b0 = new Date((S.day || dkey(Date.now())) + 'T00:00:00');
  for (let i = 6; i >= 0; i--) {
    const d = new Date(b0);
    d.setDate(d.getDate() - i);
    const k = dkey(d);
    days.push({ k, c: cnt(k), w: 'SMTWTFS'[d.getDay()] });
  }
  if (!days.some(y => y.c)) return '';
  const mx = Math.max(gl || 0, ...days.map(y => y.c), 1);
  return `<div class="wk">${days.map(y => `<div class="${gl && y.c >= gl ? 'ok' : ''}${y.k === key ? ' td' : ''}" data-a="wkday" data-k="${y.k}" role="button" tabindex="0" title="${y.k}: ${plural(y.c, 'solve')} · click to open this day"><span class="bar"><i style="height:${Math.round(y.c / mx * 100)}%"></i></span><small>${y.w}</small></div>`).join('')}</div>`;
}

// Screen time, DNFs, solving time and solves per hour for the shown day.
// Screen time = how long this page was in front (tab visible and window focused), counted per day for the whole site.
function tilesHtml() {
  const L = D().solves, key = view || S.day || dkey(Date.now()), scrMs = (S.stime || {})[key] || 0,
        scrTile = `<div><small>Screen time</small><b${view ? '' : ' class="stv"'}>${dur(scrMs)}</b></div>`;
  if (!L.length) return `<div class="tsum">${scrTile}</div>`;
  const tt = L.reduce((a, y) => a + (y.t || 0), 0), span = L[L.length - 1].d - L[0].d, pace = span >= 3e5 ? Math.round((L.length - 1) / (span / 36e5)) : 0;
  return `<div class="tsum">${scrTile}<div><small>DNFs</small><b>${L.filter(y => y.p === 'D').length}</b></div><div><small>Solving time</small><b>${dur(tt)}</b></div><div><small>Solves/hour</small><b>${pace || '–'}</b></div></div>`;
}

// Counts the time the page is in front. Ticks once a second; a gap over 5 s (computer asleep) is ignored.
let stLast = Date.now(), stSaved = 0, stPushed = Date.now();
setInterval(() => {
  const now = Date.now(), dt = now - stLast;
  stLast = now;
  if (document.visibilityState !== 'visible' || !document.hasFocus() || dt <= 0 || dt > 5000) return;
  S.stime = S.stime || {};
  const k = dkey(now);
  S.stime[k] = (S.stime[k] || 0) + dt;
  if (!view) document.querySelectorAll('.stv').forEach(el => { el.textContent = dur(S.stime[k]); });
  if (now - stSaved > 15000) {
    stSaved = now;
    if (now - stPushed > 300000) { stPushed = now; histCheck = true; save(); }   // full save (also syncs the account)
    else persist();   // screen time alone stays on this device
  }
}, 1000);

// Right column: daily goal, day streak, last 7 days, and a few numbers for today's session.
function goalPanel() {
  const gl = S.set.goal, key = view || S.day || dkey(Date.now()), cnt = k => cubeDay(k),
        gc = cnt(key), sk = view ? 0 : streak(), bestSk = Math.max(recOf(S.cur).days || 0, sk), pc = gl ? Math.min(100, Math.round(gc / gl * 100)) : 0;
  let g = '', h = '';
  if (gl) g = `<small>Daily goal</small><div class="gbar"><i style="width:${pc}%"></i></div><small>${gc} / ${gl} solves${view ? '' : ' today'} · ${pc}%${gc >= gl ? ' ✓' : ` · ${gl - gc} to go`}${gc > gl ? ` (+${gc - gl} bonus)` : ''}</small>`;
  if (sk > 1) h += `<div class="sk">🔥 ${sk}-day streak${bestSk > sk ? ` <small>(best ${bestSk})</small>` : ''}</div>`;
  h += weekHtml(key);
  // only the daily goal box (bar + numbers) opens the progress graph and has the border; streak, week and tiles are outside it
  // (with no daily goal set, the streak/week part becomes the button so the graph can still be opened)
  const btn = (html, c = '') => `<div class="gbtn ${c}" data-a="progress" role="button" tabindex="0" title="Show my progress graph">${html}</div>`;
  return (g ? btn(g, 'gg') + h : btn(h)) + tilesHtml();
}

// Detail lines for one solve in its popup: PB, rank that day, percentile, penalties.
function solveInfo(s) {
  const L = D().solves, v = val(s), dv = L.map(val).filter(isFinite), line = t => `<div class="dtl">${t}</div>`;
  let h = '';
  if (s.pb) {
    let b = Infinity;
    for (const y of allSolves(S.cur)) { if (y === s) break; b = Math.min(b, val(y)); }
    h += line(`★ Personal best${isFinite(b) ? ` · beat the old record of ${fx(b)} by ${ds(b - v)}s` : ''}`);
  }
  if (isFinite(v) && dv.length) {
    const m = mn(dv), fin = allSolves(S.cur).map(val).filter(isFinite);
    h += line(`Rank ${dv.filter(y => y < v).length + 1} of ${dv.length} that day · ${ds(v - m)}s ${v < m ? 'faster' : 'slower'} than that day's mean (${fx(m)})`);
    if (fin.length >= 20) h += line(`Faster than ${Math.round(fin.filter(y => y > v).length / fin.length * 100)}% of all ${fin.length} ${esc(name())} solves`);
  }
  if (s.p === 2) h += line('Includes +2 (inspection past 15 s or a judge penalty)');
  if (s.r) h += line('Round ' + s.r);
  return h;
}

// Records window: best single and averages, totals, streaks, sub-X badges and the last personal bests.
function records() {
  const c = curCube(), P = profile(c), L = allSolves(c.id), v = L.map(val), fin = v.filter(isFinite), fm = x => isFinite(x) ? fx(x) : '–',
        tile = (l, x, sub) => `<div><small>${l}</small><b>${x}</b>${sub ? `<small>${sub}</small>` : ''}</div>`,
        dt = s => s && s.d ? new Date(s.d).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }) : '';
  if (!L.length) { open(`<h3>Records · ${esc(c.n)}</h3><p class="lead">No solves yet on this cube. Records appear as soon as you start solving.</p>`); return; }
  const best = minOf(fin), bs = L.find(s => val(s) === best), tot = L.reduce((a, s) => a + (s.t || 0), 0), dn = L.filter(s => s.p === 'D').length,
        perDay = Object.keys(S.hist).sort().map(k => (S.hist[k][c.id] || { solves: [] }).solves.length).concat((S.data[c.id] || { solves: [] }).solves.length).filter(Boolean),
        sk = streak(c.id), prog = fin.length >= 50 ? mn(fin.slice(0, 25)) - mn(fin.slice(-25)) : NaN, nxt = P.subs.find(x => best >= x * 1000);
  let b = Infinity;
  const pbs = [];
  for (const s of L) { const q = val(s); if (!isFinite(q)) continue; if (s.pb) pbs.push({ s, g: b - q }); if (q < b) b = q; }
  open(`<h3>Records · ${esc(c.n)}</h3>
<div class="dtiles">${tile('Best single', fm(best), dt(bs))}${tile('Best ao5', fm(rollMin(v, 5)))}${tile('Best ao12', fm(rollMin(v, 12)))}${tile('Best ao100', fm(rollMin(v, 100)))}${tile('Mean', fm(mn(fin)))}${tile('Solves', L.length, dn ? plural(dn, 'DNF') : '')}${tile('Solving time', dur(tot))}${tile('Days cubed', perDay.length, 'best day: ' + Math.max(0, ...perDay))}${tile('PBs ★', L.filter(s => s.pb).length)}${tile('Best streak', (recOf(c.id).streak || 0) + ' fast', 'in a row under average')}${tile('Day streak', sk, 'best ' + Math.max(recOf(c.id).days || 0, sk))}${isNaN(prog) ? '' : tile('Progress', (prog >= 0 ? '−' : '+') + ds(prog) + 's', 'first 25 vs latest 25')}</div>
${P.subs.length && isFinite(best) ? `<h4>Sub-X targets</h4><div class="chips">${P.subs.map(x => best < x * 1000 ? `<span class="ok">sub-${x} ✓</span>` : x === nxt ? `<span class="nx">🎯 sub-${x}: ${ds(Math.max(best - x * 1000, 10))}s to go</span>` : `<span class="lk">sub-${x}</span>`).join('')}</div>` : ''}
<h4>Latest personal bests</h4>${pbs.length ? pbs.slice(-10).reverse().map(p => `<div class="dsum"><b>★ ${fmtS(p.s)}</b> <span class="dtl">${dt(p.s)}${isFinite(p.g) ? ` · ${ds(p.g)}s faster than the previous best` : ''}</span></div>`).join('') : '<p class="lead">No personal bests yet. They start counting after 5 solves.</p>'}`);
}

function add(t, p, why) {
  undoDel = [];
  rollover();
  const e = D(), s = { t, p, s: scr, d: Date.now(), r: S.set.auto ? e.round : 0 }, x = react(s, why), off = S.set.tone === 'off';
  e.solves.push(s);
  tm.textContent = fmtS(s);
  focusUI();
  if (S.set.auto) {
    const rs = e.solves.filter(y => y.r === e.round);
    if (rs.length >= 5) {
      const vs = rs.map(val), res = ao5(arr(vs)), old = pastRounds(S.cur).concat(e.rounds).map(y => y.res).filter(isFinite),
            ob = minOf(old), prv = old[old.length - 1], rn = e.round, sv = [...vs].sort((a, b) => a === b ? 0 : a - b),
            dropped = `${fx(sv[0])} and ${fx(sv[4])} dropped`, nb = isFinite(res) && old.length > 0 && res < ob && !off;
      e.rounds.push({ n: rn, res, v: rs.map(fmtS) });
      let tx;
      if (!isFinite(res)) tx = `🧩 Round ${rn} finished as a DNF (two or more DNFs).`;
      else if (nb) {
        tx = `🏆 NEW BEST AO5! Round ${rn}: ${fx(res)} beats your old best of ${fx(ob)} by ${ds(ob - res)}s. Congratulations! (${dropped})`;
        if (pbOn('pb5')) bump(x, 'pb');
      } else {
        tx = `✅ Round ${rn} done · ao5 ${fx(res)} (${dropped}).`;
        if (isFinite(prv)) tx += ` ${ds(res - prv)}s ${res < prv ? 'faster' : 'slower'} than your previous round.`;
        if (isFinite(ob) && res > ob && prv !== ob) tx += ` ${ds(res - ob)}s off your best ao5 (${fx(ob)}).`;
      }
      x.events.push({ k: nb && pbOn('pb5') ? 'pb' : 'round', text: tx + ` Round ${rn + 1} starts now.` });
      // the same details as the round popup: the five times (best and worst in brackets) and their scrambles
      const lo = vs.indexOf(Math.min(...vs)), hi = vs.indexOf(Math.max(...vs)), fullDet = S.set.det !== 'short';
      x.events.push({ k: 'rsum', text: `<div class="chips">${rs.map((y, k) => { const t = fmtP(y); return `<span><small>${ORD[k]}</small> <b>${k === lo || k === hi ? '(' + t + ')' : t}</b></span>`; }).join('')}</div>` +
        (fullDet ? `<details class="rsd"><summary>Scrambles</summary><div class="dtl">Best and worst are dropped (in brackets).</div>` + rs.map((y, k) => `<div class="dtl"><b>${ORD[k]}</b> · <span style="font-family:ui-monospace,monospace;white-space:pre-wrap">${esc(y.s || '(scramble not kept)')}</span></div>`).join('') + `</details>` : '') +
        `<button data-a="round" data-n="${rn}" style="margin-top:6px">Open round ${rn}</button>` });
      e.round++;
    }
  }
  if (!off) {
    // rolling averages over the whole history
    const av = allSolves(S.cur).map(val);
    for (const k of [12, 50, 100]) {
      if (av.length < k) continue;
      const cur = aoN(av, k);
      if (!isFinite(cur)) continue;
      if (av.length === k) { x.events.push({ k: 'round', text: `📊 Your first ao${k} is complete: ${fx(cur)}!` }); continue; }
      const old = bestAoUpTo(S.cur, av, k, av.length - 1);
      if (isFinite(old) && cur < old) {
        const on = pbOn('pb' + k);
        x.events.push({ k: on ? 'pb' : 'round', text: `🏆 NEW BEST AO${k}! ${fx(cur)} beats your old best of ${fx(old)} by ${ds(old - cur)}s.` });
        if (on) bump(x, 'pb');
      }
    }
  }
  $('#msg').innerHTML = rx(x);
  celebrate(x.kind, x);
  save();
  newScr();
  render();
}

// Cancel button shown only during the 15 s inspection (Escape does the same on a keyboard).
const ib = document.createElement('button');
ib.id = 'icancel'; ib.type = 'button'; ib.tabIndex = -1; ib.hidden = true; ib.textContent = 'Cancel inspection';
$('#msg').after(ib);
const ibLabel = () => { ib.textContent = (mode === 'run' ? 'Cancel solve (' : 'Cancel inspection (') + keyOf('cancel') + ')'; };
// Stops a solve that is running and throws the time away (nothing is saved).
function cancelRun() {
  if (mode !== 'run') return;
  mode = 'idle';
  holding = ready = false;
  clearTimeout(ht);
  ib.hidden = true;
  tm.className = '';
  tm.textContent = '0.00';
  $('#msg').textContent = 'Solve cancelled. The time was not saved. Hold SPACE or touch to try again.';
  focusUI();
}
function cancelInsp() {
  if (mode !== 'insp') return;
  mode = 'idle';
  holding = ready = false;
  clearTimeout(ht);
  ib.hidden = true;
  tm.className = '';
  tm.textContent = '0.00';
  $('#msg').textContent = 'Inspection cancelled. Hold SPACE or touch to start again.';
  focusUI();
}
ib.addEventListener('click', () => (mode === 'run' ? cancelRun() : cancelInsp()));

// ---- Typing mode: type a time instead of using the timer ----
const ti = document.createElement('input');
ti.id = 'ti'; ti.type = 'text'; ti.inputMode = 'decimal'; ti.autocomplete = 'off'; ti.spellcheck = false; ti.hidden = true;
ti.placeholder = 'Type time, press Enter';
ti.setAttribute('aria-label', 'Type your time');
$('#msg').before(ti);

// Accepts 12.34, 23 (= 23 s), 1:23.45, DNF or D. A trailing + means the time already includes +2.
function parseTime(str) {
  let s = str.trim().toLowerCase().replace(/,/g, '.');
  if (!s) return null;
  if (s === 'dnf' || s === 'd') return { t: 0, p: 'D' };
  let p = 0;
  if (s.endsWith('+')) { p = 2; s = s.slice(0, -1).trim(); }
  let ms;
  if (/^\d+$/.test(s)) {
    ms = +s * 1000;   // digits only = whole seconds (23 = 23 s)
  } else {
    const m = s.match(/^(?:(\d+):)?(\d+)(?:\.(\d{1,3}))?$/);
    if (!m) return null;
    const min = +(m[1] || 0), sec = +m[2];
    if (m[1] && sec >= 60) return null;
    ms = (min * 60 + sec) * 1000 + +((m[3] || '').padEnd(3, '0') || 0);
  }
  if (p === 2) ms -= 2000;
  if (!(ms > 0)) return null;
  return { t: ms, p };
}

function typeSolve() {
  if (view || mode !== 'idle') return;
  const r = parseTime(ti.value);
  if (!r) {
    ti.classList.add('bad');
    $('#msg').textContent = 'Could not read that time. Try 12.34, 23 (= 23 s), 1:23.45 or DNF. Add + for a +2 time (12.34+).';
    return;
  }
  ti.classList.remove('bad');
  ti.value = '';
  add(r.t, r.p);
  ti.focus();
}

ti.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); typeSolve(); } });
ti.addEventListener('input', () => ti.classList.remove('bad'));

// Shows or hides the typing box and keeps the two small toggle buttons in sync.
function syncMode() {
  const typing = !!S.set.typing;
  document.body.classList.toggle('typing', typing);
  ti.hidden = !(typing && !view);
  for (const [id, on] of [['#ty', typing], ['#rn', !!S.set.rnd]]) {
    const b = $(id);
    if (b) { b.classList.toggle('on', on); b.setAttribute('aria-pressed', String(on)); }
  }
}

// Laptop/desktop layout: New/Random/Type icons sit in the top bar next to the date, and the menu buttons (except the date) stack at the top of the side column.
// Phones and tablets keep the old layout.
const toolsBox = document.querySelector('.tools'), menuBox = document.querySelector('header .menu'), scrBox = $('#scr');
const sideMenu = document.createElement('div');
sideMenu.id = 'sidemenu';
$('#side').prepend(sideMenu);
const menuBtns = [...menuBox.querySelectorAll(':scope > button:not(#dt)')];
const wideMq = matchMedia('(min-width: 801px) and (min-height: 521px)');
function placeTools() {
  const w = wideMq.matches;
  document.body.classList.toggle('wide', w);
  if (w) {   // wide: the scramble sits in the middle of the top bar, the icons left of the date
    menuBox.prepend(toolsBox);
    document.querySelector('header .sp').before(scrBox);
  } else {
    $('#scw').prepend(scrBox);
    scrBox.after(toolsBox);
  }
  for (const b of menuBtns) (w && b.dataset.a !== 'set' ? sideMenu : menuBox).appendChild(b);   // wide: Settings stays in the top bar, right of the date
  placeSide();
}
// Side bar off (wide layout): the same panel moves into the timer area and floats on its right side.
function placeSide() {
  const side = $('#side'), tzEl = $('#tz'), wrap = $('#wrap'), inside = wideMq.matches && !S.set.showSide;
  if (inside && side.parentNode !== tzEl) tzEl.appendChild(side);
  else if (!inside && side.parentNode !== wrap) wrap.appendChild(side);
  if (window.rdSync) window.rdSync();
}
window.placeSide = placeSide;
placeTools();
wideMq.addEventListener('change', placeTools);

function setTyping(on) {
  S.set.typing = on;
  save();
  syncMode();
  if (!view) $('#msg').textContent = hint();
  if (on && !view) ti.focus();
}


function tick() {
  focusUI();
  if (mode === 'run') {
    tm.textContent = S.set.hide ? '…' : S.set.secs ? F(performance.now() - t0, 2).split('.')[0] : F(performance.now() - t0, S.set.dec);
  } else if (mode === 'insp') {
    const e = (performance.now() - i0) / 1000;
    if (e >= 8 && !b8) { b8 = 1; beep(600); }
    if (e >= 12 && !b12) { b12 = 1; beep(900); }
    if (insp(e) < 0) {
      mode = 'idle';
      ib.hidden = true;
      tm.className = '';
      $('#msg').textContent = 'Inspection over 17 s: DNF';
      add(0, 'D', 'insp');
      return;
    }
    tm.textContent = insp_text(e);
  } else {
    return;
  }
  cancelAnimationFrame(raf);
  raf = requestAnimationFrame(tick);
}

function down() {
  if (view) return;
  if (mode === 'run') {
    const t = performance.now() - t0;
    mode = 'idle';
    ib.hidden = true;
    tm.className = '';
    add(t, pen);
    return;
  }
  holding = true;
  ready = false;
  const need = mode === 'insp' || !S.set.insp;
  if (need) tm.className = 'hold';
  ht = setTimeout(() => {
    if (holding && need) {
      ready = true;
      tm.className = 'ready';
      if (S.set.rdy) jingle([880], 0.1, 0.07);
      buzz(15);
    }
  }, S.set.hold);
}

function up() {
  if (!holding) return;
  holding = false;
  clearTimeout(ht);
  if (mode === 'idle' && S.set.insp) {
    mode = 'insp';
    i0 = performance.now();
    b8 = b12 = 0;
    pen = 0;
    ibLabel();
    ib.hidden = false;
    tm.className = 'insp';
    $('#msg').textContent = 'Inspection: hold and release to start';
    tick();
  } else if (ready) {
    pen = mode === 'insp' ? Math.max(0, insp((performance.now() - i0) / 1000)) : 0;
    mode = 'run';
    ibLabel();
    ib.hidden = false;
    t0 = performance.now();
    tm.className = '';
    $('#msg').textContent = pen ? '+2 penalty (inspection over 15 s)' : '';
    tick();
  } else {
    tm.className = mode === 'insp' ? 'insp' : '';
  }
  ready = false;
}

// ---- Keyboard shortcuts (can be changed in Settings) ----
const KEYACT = [
  ['cancel', 'Cancel inspection or running solve', 'Shift+C'],
  ['del', 'Delete last solve', 'Shift+D'],
  ['dnf', 'DNF on/off for last solve', 'D'],
  ['p2', '+2 on/off for last solve', 'Shift+2'],
  ['undo', 'Undo delete', 'Shift+Z'],
  ['scr', 'New scramble', 'N'],
  ['cubes', 'Choose a cube', 'K'],
  ['meth', 'Methods', 'M'],
  ['prog', 'Progress graph', 'P'],
  ['rec', 'Records', 'R'],
  ['cal', 'Calendar', 'C'],
  ['rules', 'Rules and info', 'I'],
  ['set', 'Settings', 'S']
];
const KEYOPEN = { cubes: 'cubes', meth: 'meth', prog: 'progress', rec: 'rec', cal: 'cal', rules: 'rules', set: 'set' };
const keyOf = a => ((S.set.keys || {})[a]) ?? KEYACT.find(x => x[0] === a)[2],
      actOf = cb => cb ? (KEYACT.find(x => keyOf(x[0]) === cb) || [])[0] : undefined;
// Same letter on any keyboard layout: built from the physical key (e.code).
function comboOf(e) {
  const c = e.code || '';
  if (!c || /^(Shift|Control|Alt|Meta|OS)(Left|Right)?$/.test(c)) return '';
  const k = /^Key[A-Z]$/.test(c) ? c.slice(3) : /^(Digit|Numpad)\d$/.test(c) ? c.slice(-1) : c;
  return (e.ctrlKey || e.metaKey ? 'Ctrl+' : '') + (e.altKey ? 'Alt+' : '') + (e.shiftKey ? 'Shift+' : '') + k;
}
const hint = () => S.set.typing ? 'Type your time and press Enter · 12.34 · 23 = 23 s · 1:23.45 · D = DNF · add + for a +2 time (12.34+)' : `Hold SPACE or touch to start · ${keyOf('del')} deletes last · ${keyOf('p2')} = +2 · ${keyOf('dnf')} = DNF`;
const keysHelp = () => `${keyOf('del')} (or Backspace/Delete) removes the last solve, ${keyOf('undo')} undoes a delete, ${keyOf('p2')} toggles +2, ${keyOf('dnf')} toggles DNF, ${keyOf('cancel')} cancels the inspection or a running solve (the time is not saved), ${keyOf('scr')} gives a new scramble. ${KEYACT.filter(x => KEYOPEN[x[0]]).map(x => keyOf(x[0]) + ' ' + x[1]).join(', ')}. You can change all of these in Settings.`;
function keyLabels() {
  ibLabel();
  const m = $('#msg');
  if (m && /^(Hold SPACE|Type your time)/.test(m.textContent)) m.textContent = hint();
  document.querySelectorAll('[data-a="keyset"]').forEach(b => { b.textContent = keyOf(b.dataset.act) || 'none'; });
}

// Runs a shortcut. Returns true when it did something.
function runKey(a) {
  const L = D().solves, s = L[L.length - 1];
  const edit = f => { if (view || !s) return false; f(); refix(); save(); render(); const l = L[L.length - 1]; tm.textContent = l ? fmtS(l) : '0.00'; return true; };
  if (a === 'del') { if (view || !s) return false; delSolve(L.length - 1); return true; }
  if (a === 'dnf') return edit(() => { s.p = s.p === 'D' ? 0 : 'D'; });
  if (a === 'p2') return edit(() => { s.p = s.p === 2 ? 0 : 2; });
  if (a === 'undo') { if (view || !undoDel.length) return false; undoSolve(); return true; }
  if (a === 'scr') { if (view) return false; fresh(); return true; }
  if (KEYOPEN[a]) { const b = document.querySelector(`[data-a="${KEYOPEN[a]}"]`); if (b) { b.click(); return true; } }
  return false;
}

// Choosing a new key in Settings: click the button, then press the keys. Esc cancels.
let capAct = null;
function endCap() { capAct = null; keyLabels(); }
document.addEventListener('keydown', e => {
  if (!capAct) return;
  e.preventDefault(); e.stopImmediatePropagation();
  if (e.code === 'Escape') { endCap(); return; }
  const cb = comboOf(e);
  if (!cb) return;                                   // only a modifier so far
  if (['Space', 'Tab', 'Enter', 'Shift+Space'].includes(cb)) { alert('Space, Tab and Enter cannot be used.'); return; }
  const other = actOf(cb);
  S.set.keys = S.set.keys || {};
  if (other && other !== capAct) S.set.keys[other] = keyOf(capAct);   // swap, so no key does two things
  S.set.keys[capAct] = cb;
  save(); endCap();
}, true);

document.addEventListener('keydown', e => {
  if (dl.open) return;
  if (e.target.closest && e.target.closest('input, textarea, select, [contenteditable]')) return;
  const act = actOf(comboOf(e));
  if (mode === 'run') {
    if (act === 'cancel') { e.preventDefault(); cancelRun(); return; }
    if (!comboOf(e)) return;   // Shift, Ctrl or Alt alone must not stop the timer (they start a shortcut)
  }
  if (mode === 'insp' && (act === 'cancel' || e.code === 'Escape')) { e.preventDefault(); cancelInsp(); return; }
  if (mode === 'idle' && !e.repeat) {
    let a = act;
    if (!a && !e.ctrlKey && !e.metaKey && !e.altKey && !e.shiftKey && (e.key === 'Backspace' || e.key === 'Delete')) a = 'del';
    if (a && runKey(a)) { e.preventDefault(); return; }
  }
  if (S.set.typing && !view && mode === 'idle') {
    if (e.code === 'Space') { e.preventDefault(); ti.focus(); }
    else if (/^[0-9]$/.test(e.key) && !e.ctrlKey && !e.metaKey && !e.altKey) ti.focus();   // the digit lands in the box
    return;
  }
  if (e.code === 'Space') {
    e.preventDefault();
    if (!e.repeat) down();
  } else if (mode === 'run') {
    down();
  }
});

document.addEventListener('keyup', e => {
  if (e.code === 'Space' && !dl.open) {
    e.preventDefault();
    up();
  }
});

document.addEventListener('pointerdown', e => {
  if (dl.open) return;
  if (e.target.closest('#icancel')) return;   // the Cancel button must not stop (and save) the timer
  if (mode === 'run') { down(); return; }
  if (e.target.closest('#tz') && !e.target.closest('button') && !e.target.closest('#side')) {
    if (S.set.typing && !view) { if (e.target !== ti) setTimeout(() => ti.focus()); return; }
    down();
  }
});

['pointerup', 'pointercancel'].forEach(t => document.addEventListener(t, () => { if (!dl.open) up(); }));

// Rounds list scrollbar: a custom bar (native scrollbars give no mouse events in Firefox).
// Double-click it to open the project page on GitHub.
{
  const rd = $('#rd'), side = $('#side'), W = 12;
  const bar = document.createElement('div');
  bar.id = 'rdbar';
  bar.title = 'Double-click: project on GitHub';
  bar.innerHTML = '<div id="rdthumb"></div>';
  side.appendChild(bar);
  const th = bar.firstChild;
  const scale = () => (rd.offsetHeight ? rd.getBoundingClientRect().height / rd.offsetHeight : 1);   // page zoom
  const sync = () => {
    const over = rd.scrollHeight - rd.clientHeight, h = rd.offsetHeight;
    if (over <= 1 || !h) { bar.classList.remove('on'); return; }
    bar.classList.add('on');
    bar.style.top = rd.offsetTop + 'px';
    bar.style.left = (rd.offsetLeft + rd.offsetWidth - W) + 'px';
    bar.style.height = h + 'px';
    const tH = Math.max(28, h * rd.clientHeight / rd.scrollHeight);
    th.style.height = tH + 'px';
    th.style.transform = 'translateY(' + (rd.scrollTop / over * (h - tH)) + 'px)';
  };
  let drag = null;
  th.addEventListener('pointerdown', e => {
    if (e.button) return;
    e.preventDefault();
    e.stopPropagation();
    th.setPointerCapture(e.pointerId);
    drag = { y: e.clientY, top: rd.scrollTop };
  });
  th.addEventListener('pointermove', e => {
    if (!drag) return;
    const room = rd.offsetHeight - th.offsetHeight, over = rd.scrollHeight - rd.clientHeight;
    if (room > 0) rd.scrollTop = drag.top + (e.clientY - drag.y) / scale() * over / room;
  });
  ['pointerup', 'pointercancel'].forEach(t => th.addEventListener(t, () => { drag = null; }));
  bar.addEventListener('pointerdown', e => {   // click on the empty track: scroll one page toward it
    if (e.button || e.target !== bar) return;
    rd.scrollTop += (e.clientY < th.getBoundingClientRect().top ? -1 : 1) * rd.clientHeight * 0.9;
  });
  bar.addEventListener('dblclick', () => window.open('https://github.com/AnontoRB/speed_cube_timer', '_blank', 'noopener'));
  rd.addEventListener('scroll', sync, { passive: true });
  new ResizeObserver(sync).observe(rd);
  new ResizeObserver(sync).observe(side);
  new MutationObserver(sync).observe(rd, { childList: true, subtree: true });
  addEventListener('resize', sync);
  window.rdSync = sync;
  sync();
}

const dlStack = [];
const dlTitle = () => { const t = dl.querySelector('h3'); return t ? t.textContent : ''; };
const open = (h, noPush) => {
  if (!dl.open) dlStack.length = 0;
  else if (!noPush) {
    const html = dl.innerHTML, sc = dl.scrollTop, t = dlTitle();
    dl.innerHTML = '<div class="dc"><div class="xw"></div>' + h + '</div>';
    const same = dlTitle() === t; // same title = refresh of this page, not a new page
    if (!same) dlStack.push({ html, sc });
  }
  dl.innerHTML = '<div class="dc"><div class="xw"><button data-a="' + (dlStack.length ? 'back' : 'close') + '" class="x" aria-label="Back" title="Back">&#8249; Back</button></div>' + h + '</div>';
  if (!dl.open) dl.showModal();
};
const dlBack = () => {
  const p = dlStack.pop();
  if (!p) { dl.close(); return; }
  dl.innerHTML = p.html;
  const x = dl.querySelector('.x'); if (x) x.dataset.a = dlStack.length ? 'back' : 'close';
  dl.scrollTop = p.sc;
};

const RULES = [
  ['a', 'New scramble for every attempt.'],
  ['a', '15 s inspection with beeps at 8 s and 12 s (can be turned off).'],
  ['a', 'Hold, wait for green, release to start. Any key or tap stops.'],
  ['a', 'Start between 15 and 17 s = +2. Past 17 s = DNF.'],
  ['a', 'Manual +2 and DNF buttons on every solve for judge penalties.'],
  ['a', 'Ao5: best and worst dropped, two or more DNFs = DNF. Times are truncated, not rounded.'],
  ['h', '3x3 OH: solve and inspect with one hand only.'],
  ['h', '3x3 BLD: the timer covers memo and solve. Put the blindfold on before you solve; any mistake is a DNF (mark it with D).'],
  ['h', 'Scrambles are random-move, not the official random-state scrambler.']
];

const INFO = [
  ['Results: single, mean and averages', [
    ['Single', 'One solve. Your best single is your fastest time ("PB" = personal best).'],
    ['Mean', 'Add up all the times and divide by how many there are. Every solve counts, the fast ones and the slow ones. In this timer, "Mean" on the home screen is the mean of all your solves today (DNFs are left out). One bad solve pulls a mean up a lot.'],
    ['Average (ao)', 'In cubing an "average" is NOT the same as a mean. An average removes the best and the worst times first, then takes the mean of the rest. That makes it fair: one lucky or one terrible solve does not decide the result.'],
    ['ao5 (average of 5)', 'Take 5 solves, remove the fastest and the slowest, then take the mean of the middle 3. This is the standard official result for most events, and it is what each Round in this timer is.'],
    ['ao12 (average of 12)', 'Last 12 solves. Remove the best 1 and the worst 1, then take the mean of the other 10. Used to see your pace over a longer stretch.'],
    ['ao100 (average of 100)', 'Last 100 solves. Remove the best 5 and the worst 5 (5%), then take the mean of the other 90. A very steady measure of your real level.'],
    ['mo3 (mean of 3)', 'Take 3 solves and take the plain mean of all three, nothing removed. Used officially for the slow big cubes (6x6 and 7x7). It is not calculated in this timer.'],
    ['Current vs best', '"Current ao5" is the average of your last 5 solves right now. "Best ao5" is the best average of 5 you ever had, counting every group of 5 in a row. ao12 and ao100 work the same way. The Records window shows your best ao5, ao12 and ao100.']
  ]],
  ['Worked example (ao5)', [
    ['Times', '28.20, 39.72, 39.06, 30.63, 16.92'],
    ['Step 1', 'Remove the fastest (16.92) and the slowest (39.72). They go in brackets: (39.72) and (16.92).'],
    ['Step 2', 'Mean of the middle three: (28.20 + 39.06 + 30.63) / 3 = 97.89 / 3 = 32.63.'],
    ['Result', 'ao5 = 32.63. That is why the 1st to 5th solve boxes show the best in green with a + and the worst in red with a −: those two times are dropped.']
  ]],
  ['Penalties, DNF and inspection', [
    ['Inspection', 'Before every solve you get 15 seconds to look at the scrambled cube (you may not touch it to turn it). The timer counts down and beeps at 8 s and 12 s.'],
    ['+2', 'A 2 second penalty added to your time. Starting your solve between 15 and 17 seconds of inspection gives +2. A judge can also give +2 (for example if the cube is one move from solved when you stop). A +2 time is written like 12.34+.'],
    ['DNF', '"Did Not Finish". The solve does not count as a time. You get it for starting after 17 s of inspection, stopping with the cube not solved, or a serious rule break.'],
    ['DNF in averages', 'One DNF in an ao5 is allowed: it counts as the worst time and is dropped. Two or more DNFs make the whole ao5 a DNF. In a mean of 3, any DNF makes the result a DNF.'],
    ['Stopping', 'The solve ends when you stop the timer. The cube must be fully solved when you stop, or it is a DNF.']
  ]],
  ['Scrambles and rounds', [
    ['Scramble', 'A fixed list of moves that mixes the cube. Everyone doing the same scramble starts with the same puzzle, which makes times fair. Hold the cube the same way every time: white on top, green in front (the standard orientation), then apply the scramble.'],
    ['Move letters', 'U = Up, D = Down, R = Right, L = Left, F = Front, B = Back face. Turn that face 90° clockwise as you look at it. A \' (prime) means counter-clockwise. A 2 means turn 180°. On big cubes a "w" means turn the outer two layers together (wide).'],
    ['Round', 'In this timer one round is 5 solves. After the 5th solve the ao5 of the round is calculated and a new round starts. Click a round in the list on the right to open it and see its solves and scrambles. Turn Auto rounds off in Settings if you do not want this.'],
    ['★ (star)', 'A personal best. A solve gets a star when it is faster than every earlier solve (after your first 5 solves). A round gets a star when it is your best ao5.'],
    ['Truncating', 'Single times are cut off (truncated), not rounded: 12.349 shows as 12.34. Official results round averages to the nearest hundredth, so an official average can differ from this timer by 0.01.']
  ]],
  ['Getting better', [
    ['Sub-X', 'Faster than X seconds. "Sub-20" means every solve under 20.00 s. In the Records window you see which sub-X targets you reached and how close the next one is.'],
    ['Consistency', 'Fast cubers care more about their average than their best single. A good single can be luck; a good ao12 or ao100 shows skill. Try to lower your ao12 slowly.'],
    ['Look-ahead', 'Plan the next piece while you solve the current one so you never stop to look. This is the biggest speed-up for most people.'],
    ['TPS', 'Turns per second. Faster fingers help, but smooth turning with no pauses matters more than raw speed.'],
    ['Methods', 'Every cube has its own methods: CFOP (cross, F2L, OLL, PLL) on the 3x3, Reduction and Yau on big cubes, Ortega and CLL on the 2x2, and more. The Methods button lists steps and algorithms, and you can tick the ones you know.'],
    ['Solves/hour', 'Shown in the side column. Practice pace: it only counts once you solved for at least 5 minutes in a day.']
  ]],
  ['Keys and controls', [
    ['Start', 'Hold SPACE (or touch the timer area) until it turns green, then release. Any key or tap stops the timer.'],
    ['Shortcuts', '%KEYS%'],
    ['Click a solve', 'Click a 1st to 5th solve box to see its scramble and time, add +2 or DNF, or delete it.']
  ]]
];

function rulesInfo() {
  const sec = ([t, items]) => `<section class="dcard sg"><h4>${t}</h4>${items.map(([k, v]) => `<p style="margin:8px 0"><b>${k}</b><br>${v === '%KEYS%' ? keysHelp() : v}</p>`).join('')}</section>`;
  open('<h3>Rules and info</h3><p class="lead" style="margin:0">Everything you need to know for competitive cubing (WCA based). Green tag: applied automatically by this timer. Grey tag: honor system.</p>' +
    '<h4>Timer rules</h4><ul style="padding-left:18px">' + RULES.map(r => `<li><span class="tg ${r[0] == 'h' ? 'h' : ''}">${r[0] == 'a' ? 'applied' : 'honor'}</span>${r[1]}</li>`).join('') + '</ul>' +
    INFO.map(sec).join(''));
  dl.scrollTop = 0;
}

// Parts of the side panel. Each part is on or off. "Show side bar" (Settings) decides WHERE the parts that are on appear:
// docked in the right bar, or (bar off) inside the timer area on its right side.
const SIDE_PARTS = [['showMenu', 'Menu buttons'], ['showGoal', 'Daily goal'], ['showSk', 'Streak'], ['showWk', 'Week chart'], ['showTl', 'Stat tiles'], ['showRd', 'Rounds']];
const sideOn = k => S.set[k] !== false;

// Redraw the "Choose a cube" window after a click and keep it scrolled where it was (the buttons apply at once and the window stays open).
function keepPick() { const t = dl.scrollTop; cubePicker(); dl.scrollTop = t; }

function cubePicker() {
  const one = c => `<span class="cb"><button data-a="cube" data-i="${c.id}" class="${c.id === S.cur || (c.id === '3' && typeof isPrac === 'function' && isPrac(S.cur)) ? 'on' : ''}">${esc(c.n)}${c.id === '3' && typeof on3 === 'function' && on3() ? ' &#9662;' : ''}</button>${c.meth ? '' : `<button data-a="rmcube" data-i="${c.id}" class="rm" title="Remove">&times;</button>`}</span>`,
        all = allCubes(), std = ['2', '3', '4', '5', '6', '7'], var3 = ['oh', 'bld'], oth = ['pyra', 'skewb', 'mega'],
        grp = (t, f) => { const l = all.filter(f); return l.length ? `<h4>${t}</h4><div class="cubes">${l.map(one).join('')}</div>` : ''; };
  open(`<h3>Choose a cube</h3>${grp('Cubes', c => std.includes(c.id))}${typeof pracHint === 'function' ? pracHint() : ''}${grp('One-handed and blindfolded', c => var3.includes(c.id))}${grp('Other puzzles', c => oth.includes(c.id))}${grp('My cubes', c => !c.meth)}<h4>Add your own cube</h4><div class="add"><input id="cn" placeholder="Name (e.g. Mirror cube)" maxlength="24"><select id="ct">${CTYPES.map(x => `<option value="${x[0]}">${x[1]}</option>`).join('')}</select><button data-a="addcube" class="on">Add</button></div><p class="lead">Pick which scramble it uses. Custom cubes get their own times and a notes page under Methods.</p><h4>Side panel</h4><div class="row btns"><button data-a="sidetoggle">${S.set.showSide ? 'Hide the right side bar' : 'Show the right side bar'}</button></div><p class="lead">Bar on: the highlighted parts appear in the bar on the right. Bar off: they appear inside the timer area, on its right side. Highlighted = shown. Click a part to hide or show it.</p><div class="cubes">${SIDE_PARTS.map(x => `<button data-a="sidepart" data-k="${x[0]}" class="${sideOn(x[0]) ? 'on' : ''}" aria-pressed="${sideOn(x[0])}">${x[1]}</button>`).join('')}<button data-a="sideall" class="all">${SIDE_PARTS.every(x => sideOn(x[0])) ? 'Turn all off' : 'Turn all on'}</button></div><p class="lead">If you hide the menu buttons, come back here to show them again.</p>`);
}

function wallPrev() {
  const el = $('#wp');
  if (!el) return;
  el.style.backgroundImage = WALL ? `url("${WALL}")` : '';
  el.classList.toggle('empty', !WALL);
  el.textContent = WALL ? '' : 'No picture';
}

function settings() {
  const s = S.set,
        c = (k, l) => `<label class="set"><span class="lb">${l}</span><input type="checkbox" data-k="${k}" ${s[k] ? 'checked' : ''}></label>`,
        r = (k, l, a, b, st) => `<label class="set"><span class="lb">${l}: <span id="v_${k}">${s[k]}</span></span><input type="range" data-k="${k}" min="${a}" max="${b}" step="${st}" value="${s[k]}"></label>`,
        col = (k, l) => `<label class="set"><span class="lb">${l}</span><input type="color" data-k="${k}" value="${s[k]}"></label>`,
        sl = (k, l, o) => `<label class="set"><span class="lb">${l}</span><select data-k="${k}">${o.map(x => `<option value="${x[0]}" ${s[k] == x[0] ? 'selected' : ''}>${x[1]}</option>`).join('')}</select></label>`,
        g = (t, h) => `<section class="dcard sg"><h4>${t}</h4>${h}</section>`;
  open(`<h3>Settings</h3>
${g('Theme and colors', sl('theme', 'Theme', [['dark', 'Dark'], ['light', 'Light'], ['custom', 'Custom']]) + col('bg', 'Background') + col('fg', 'Text') + col('ac', 'Accent') + col('rd', 'Ready color (green)') + col('hd', 'Hold color (red)'))}
${g('Wallpaper', '<div class="wall"><div id="wp" class="wp"></div><div class="bg"><button data-a="wpick">Choose picture</button><button data-a="wrm" class="danger">Remove</button></div></div><input type="file" id="wf" accept="image/*" hidden><p class="lead">Any picture from your device. It is shrunk to fit and saved on this device only.</p>' + r('wallDim', 'Darkness over the picture (%)', 0, 90, 5) + r('cardOp', 'Opacity of the boxes on the home screen (%)', 0, 100, 5) + r('sideOp', 'Opacity of the side panel (%)', 0, 100, 5))}
${g('Layout', r('ui', 'Interface size (%)', 70, 150, 5) + r('rad', 'Corner roundness (px)', 0, 24, 1) + r('th', 'Timer area height (%)', 30, 70, 2) + c('showScr', 'Show scramble') + c('showRs', 'Show 1st to 5th solve boxes') + c('showSt', 'Show stats (best, mean, ao5)') + c('showSide', 'Show the right side bar (off = its parts appear inside the timer area)'))}
${g('Text', sl('tf', 'Timer font', [['system', 'System'], ['mono', 'Monospace'], ['serif', 'Serif'], ['rounded', 'Rounded']]) + r('tw', 'Timer weight', 300, 800, 100) + r('fs', 'Timer size', 40, 200, 2) + sl('dec', 'Decimals', [[2, '2'], [3, '3']]) + r('ss', 'Scramble size', 12, 36, 1) + c('sfm', 'Monospace scramble'))}
${g('Entering solves', c('typing', 'Type times in (no timer, press Enter to save)') + c('rnd', 'Scramble: save as "Random" (no scramble is generated)'))}
${g('Saved data', sl('keepScr', 'Keep the scramble of old solves', [['all', 'Forever'], ['365', '1 year'], ['90', '90 days'], ['30', '30 days']]) + '<p class="lead">Older solves keep their times; only the scramble text is dropped, which keeps your saved and synced data small. Recent days are never touched. Dropped scrambles cannot be brought back.</p>')}
${g('Timing and sound', r('hold', 'Hold time (ms)', 0, 1000, 50) + c('insp', '15 s inspection') + c('snd', 'Inspection beeps') + r('vol', 'Beep volume (%)', 0, 100, 5) + c('focus', 'Focus mode (hide everything while solving)') + c('hide', 'Hide time while solving') + c('secs', 'Show whole seconds only while solving') + c('auto', 'Auto rounds (new round after each ao5)'))}
${g('Reactions and fun', sl('tone', 'Reactions', [['fun', 'Fun (cheers, comfort, playful teasing)'], ['kind', 'Kind (cheers and comfort only)'], ['off', 'Off']]) + sl('det', 'Message detail', [['full', 'Detailed (numbers, comparisons, tips)'], ['short', 'Short (headline only)']]) + c('brk', 'Suggest a break after several slow solves') + r('goal', 'Daily solve goal (0 = off)', 0, 200, 5))}
${g('Effects', c('fx', 'Confetti and glow') + r('fxi', 'Effects strength (1 = subtle, 3 = wild)', 1, 3, 1) + c('vib', 'Vibration (phones)') + c('sfx', 'Sound effects') + c('pbm', 'Joyful music on a new PB') + c('pbS', 'Celebrate a new best single') + c('pb5', 'Celebrate a new best ao5') + c('pb12', 'Celebrate a new best ao12') + c('pb50', 'Celebrate a new best ao50') + c('pb100', 'Celebrate a new best ao100') + c('rdy', 'Blip when the timer turns green') + '<div class="row btns"><button data-a="fxtest">Preview effects (closes this window)</button></div>')}
${g('Keyboard shortcuts', '<p class="lead" style="margin:0 0 6px">Click a key, then press the keys you want (for example Shift+D). Esc cancels. If a key is already used, the two swap. Space is always the timer.</p>' + KEYACT.map(x => `<div class="set"><span class="lb">${x[1]}</span><button data-a="keyset" data-act="${x[0]}">${keyOf(x[0])}</button></div>`).join('') + '<div class="row btns"><button data-a="keyreset">Reset keys to default</button></div>')}
${g('Your data', '<div class="row btns"><span class="bg"><button data-a="exp">Export data</button><button data-a="imp">Import data</button></span><span class="bg">' + (view ? '' : '<button data-a="delall">Delete everything</button>') + '<button data-a="rst">Reset settings</button></span></div>')}`);
  wallPrev();
}

dl.addEventListener('input', e => {
  if (e.target.id === 'nt') { curCube().notes = e.target.value; save(); return; }
  const k = e.target.dataset.k;
  if (!k) return;
  const s = S.set;
  let v = e.target.type === 'checkbox' ? e.target.checked : e.target.value;
  if (e.target.type === 'range') {
    v = +v;
    const sp = $('#v_' + k);
    if (sp) sp.textContent = v;
  }
  if (k === 'dec') v = +v;
  s[k] = v;
  if (k === 'keepScr') trimScr();
  if (k === 'rnd') newScr();
  if (k === 'typing' && !view && mode === 'idle') $('#msg').textContent = hint();
  if (k === 'theme' && PRE[v]) {
    Object.assign(s, PRE[v]);
    settings();
  } else if (['bg', 'fg', 'ac'].includes(k)) {
    s.theme = 'custom';
  }
  applyTheme();
  save();
  render();
});

let sel = -1;

dl.addEventListener('click', e => {
  if (e.target === dl) { dl.close(); return; } // click outside the window (on the dark backdrop)
  const rr = e.target.closest('[data-a=round]');
  if (rr) { openRound(+rr.dataset.n); return; }
  const wd = e.target.closest('[data-a=wkday]');
  if (wd) { openDay(wd.dataset.k); return; }
  const b = e.target.closest('button');
  if (!b) return;
  const a = b.dataset.a, d = D(), s = d.solves[sel];
  if (view && ['p2', 'dnf', 'del', 'yes1', 'yes2', 'delall'].includes(a)) return;
  if (a === 'back') dlBack();
  else if (a === 'close') dl.close();
  else if (a === 'calm') { cal.m += +b.dataset.d; if (cal.m < 0) { cal.m = 11; cal.y--; } else if (cal.m > 11) { cal.m = 0; cal.y++; } calendar(); }
  else if (a === 'calday') calendar(b.dataset.k);
  else if (a === 'pg') progress(b.dataset.s);
  else if (a === 'wpick') $('#wf').click();
  else if (a === 'wrm') { WALL = ''; try { localStorage.removeItem('ct2wall'); } catch (err) {} applyTheme(); wallPrev(); }
  else if (a === 'rst') { if (confirm('Reset all settings to their defaults? Your solves are not touched.')) { S.set = defSet(); applyTheme(); save(); render(); settings(); } }
  else if (a === 'openday') { view = b.dataset.k === S.day ? null : b.dataset.k; dl.close(); fresh(); }
  else if (a === 'cube') {
    if (b.dataset.i === '3' && typeof on3 === 'function' && on3()) { pracMenu(); return; }   // 3x3 tapped again: practice modes
    S.cur = b.dataset.i; save(); fresh(); keepPick();
  }
  else if (a === 'sidepart') { S.set[b.dataset.k] = S.set[b.dataset.k] === false; applyTheme(); save(); render(); keepPick(); }
  else if (a === 'sideall') { { const allOn = SIDE_PARTS.every(x => sideOn(x[0])); SIDE_PARTS.forEach(x => { S.set[x[0]] = !allOn; }); } applyTheme(); save(); render(); keepPick(); }
  else if (a === 'sidetoggle') { S.set.showSide = !S.set.showSide; applyTheme(); save(); render(); keepPick(); }
  else if (a === 'addcube') {
    const n = $('#cn').value.trim();
    if (!n) { $('#cn').focus(); return; }
    (S.custom = S.custom || []).push({ id: 'c' + Date.now(), n, t: $('#ct').value, meth: null });
    S.cur = S.custom[S.custom.length - 1].id;
    save(); fresh(); keepPick();
  } else if (a === 'rmcube') {
    const c = allCubes().find(x => x.id === b.dataset.i);
    if (c && confirm('Remove ' + c.n + ' and all its solves?')) {
      S.custom = S.custom.filter(x => x.id !== c.id);
      undoDel = undoDel.filter(u => u.ev !== c.id);
      delete S.data[c.id];
      for (const k in S.hist) delete S.hist[k][c.id];
      histCheck = true;
      if (S.rec && S.rec.c) delete S.rec.c[c.id];
      if (S.cur === c.id) S.cur = '3';
      save(); newScr(); tm.textContent = '0.00'; render(); keepPick();
    }
  }
  else if (a === 'fxtest') { dl.close(); setTimeout(() => celebrate('pb', { big: true }), 150); }
  else if (a === 'mt') methods(b.dataset.m, b.dataset.t);
  else if (a === 'solve') openSolve(+b.dataset.i);
  else if (a === 'exp') {
    const l = document.createElement('a');
    // the whole app state goes into the file: solves, history, records, custom cubes, settings and look (anything new added to S or S.set is included automatically), plus the wallpaper
    const out = { ...S, app: 'cubetimer', fmt: 2, exported: Date.now() };
    if (WALL) out.wall = WALL;
    // also a raw copy of everything this browser has stored for the app (any key, so nothing is missed); only the sign-in token is left out, because anyone holding the file could use it to log in
    try { out.storage = {}; for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (k !== 'ct2auth' && !k.startsWith(HK)) out.storage[k] = localStorage.getItem(k); } } catch (e) {}
    if (AUTH && AUTH.user) out.account = { user: AUTH.user };
    l.href = URL.createObjectURL(new Blob([JSON.stringify(out)], { type: 'application/json' }));
    l.download = 'cubetimer-backup-' + dkey(Date.now()) + '.json';
    document.body.appendChild(l);
    l.click();
    setTimeout(() => { l.remove(); URL.revokeObjectURL(l.href); }, 2000);
  } else if (a === 'imp') {
    const i = document.createElement('input');
    i.type = 'file';
    i.accept = '.json';
    i.onchange = () => i.files[0].text().then(t => {
      try {
        const J = JSON.parse(t);
        if (!J || !J.data || typeof J.data !== 'object') throw 0;
        pendImp = J;
        const M = mergeState(J), before = countAll(S), after = countAll(M), inFile = countAll(J);
        open(`<h3>Import data</h3><p>This file has <b>${plural(inFile, 'solve')}</b>. You have <b>${plural(before, 'solve')}</b> here now.</p><p><b>Merge</b> keeps everything you have and adds the file: <b>${plural(after - before, 'new solve')}</b> will be added${inFile - (after - before) > 0 ? ` (${inFile - (after - before)} already here, skipped)` : ''}. Solves from the same day and cube are put in time order and the rounds are renumbered.</p><p><b>Replace</b> deletes what you have now and uses only the file.</p>${J.set ? '<p><label><input type="checkbox" id="impset" checked> Also import the <b>settings and look</b> from this file (theme, layout, typing mode, random scramble, goal, keys, custom cubes' + (J.wall ? ', wallpaper' : '') + ')</label></p>' : '<p class="dtl">This file has no settings (older export), so only the solves are imported.</p>'}<div class="row btns"><button data-a="close">Cancel</button><button data-a="impreplace" class="danger">Replace everything</button><button data-a="impmerge" class="on">Merge</button></div>`);
      } catch (x) { alert('Invalid file'); }
    });
    i.click();
  } else if (a === 'impmerge' && pendImp) {
    S = mergeState(pendImp);
    histCheck = true;
    if (wantSet()) applySet(S, pendImp);
    for (const id of new Set([...Object.keys(S.data), ...Object.values(S.hist).flatMap(h => Object.keys(h))])) { repb(id); repRec(id); }
    save(); location.reload();
  } else if (a === 'impreplace' && pendImp) {
    const keep = S.set, N = { ...pendImp };
    for (const k of ['app', 'fmt', 'exported', 'wall']) delete N[k];
    N.set = keep;
    S = N;
    histCheck = true;
    if (wantSet()) applySet(S, pendImp);
    save(); location.reload();
  } else if ((a === 'p2' || a === 'dnf') && s) { const v = a === 'p2' ? 2 : 'D'; s.p = s.p === v ? 0 : v; refix(); save(); render(); dl.close(); }
  else if (a === 'del') { dl.close(); delSolve(sel); }
  else if (a === 'yes2') {
    // final step: wipe every solve, round, past day and record on every cube
    S.data = {};
    S.hist = {};
    histCheck = true;
    S.rec = { c: {}, v: 1 };
    undoDel = [];
    AOC = {};
    save(); newScr(); tm.textContent = '0.00'; $('#msg').textContent = 'Everything was deleted.'; render(); dl.close();
  }
  else if (a === 'yes1') open(`<h3>Last chance: delete EVERYTHING?</h3><p><b>This is the final confirmation (2 of 2).</b> All solves, rounds, calendar history and records on all cubes will be permanently deleted. Your settings, wallpaper and custom cubes are kept. It cannot be undone.</p><div class="row btns"><button data-a="close">No, keep my data</button><button data-a="yes2" class="danger">Yes, delete everything now</button></div>`);
  else if (a === 'delall') open(`<h3>Delete everything?</h3><p><b>Confirmation 1 of 2.</b> This deletes ALL your solves on ALL cubes, including today and every earlier day in the calendar, plus your records and personal bests. It cannot be undone. Tip: use Export data first if you want a backup.</p><div class="row btns"><button data-a="close">Cancel</button><button data-a="yes1" class="danger">Continue</button></div>`);
});

document.addEventListener('click', e => {
  const b = e.target.closest('button, [data-a]');
  if (!b || dl.contains(b)) return;
  const a = b.dataset.a;
  b.blur();
  if (a === 'cubes' && mode === 'idle') cubePicker();
  else if (a === 'cal' && mode === 'idle') { cal.sel = ''; calendar(); }
  else if (a === 'today') { view = null; fresh(); }
  else if (a === 'newscr' && mode === 'idle' && !view) fresh();
  else if (a === 'typing' && mode === 'idle') setTyping(!S.set.typing);
  else if (a === 'rnd' && mode === 'idle' && !view) { S.set.rnd = !S.set.rnd; save(); newScr(); syncMode(); }
  else if (a === 'rules') rulesInfo();
  else if (a === 'keyset') { capAct = b.dataset.act; b.textContent = 'Press keys…'; }
  else if (a === 'keyreset') { S.set.keys = {}; capAct = null; save(); keyLabels(); }
  else if (a === 'set') settings();
  else if (a === 'acct' && mode === 'idle') account();
  else if (a === 'rec' && mode === 'idle') records();
  else if (a === 'meth') methods();
  else if (a === 'solve') openSolve(+b.dataset.i);
  else if (a === 'round') openRound(+b.dataset.n);
  else if (a === 'wkday' && mode === 'idle') openDay(b.dataset.k);
  else if (a === 'mini' && mode === 'idle') todayInfo();
  else if (a === 'progress' && mode === 'idle') progress();
  else if (a === 'x' && mode === 'idle') {
    delSolve(+b.dataset.i);
  } else if (a === 'undo') {
    undoSolve();
  }
});

// Progress graph: every solve as a dot, rolling ao5 / ao12 lines and a trend line, for today or for all time.
let chartScope = 'day';
function progress(scope) {
  if (scope) chartScope = scope;
  // Opened from the goal box with fewer than 3 solves today: show all time instead of an empty "Today" tab.
  if (!scope && chartScope !== 'all' && D().solves.map(val).filter(isFinite).length < 3 && allSolves(S.cur).map(val).filter(isFinite).length >= 3) chartScope = 'all';
  const day = chartScope !== 'all', L = day ? D().solves : allSolves(S.cur), n = L.length, v = L.map(val), fin = v.filter(isFinite),
        head = `<h3>Progress · ${esc(name())}</h3><div class="row tabs"><button data-a="pg" data-s="day" class="${day ? 'on' : ''}">${view ? 'That day' : 'Today'}</button><button data-a="pg" data-s="all" class="${day ? '' : 'on'}">All time</button></div>`;
  if (fin.length < 3) { open(head + '<p class="lead">Do a few more solves and your progress graph will show up here (it needs at least 3 times).</p>'); return; }
  const W = 600, H = 260, ml = 48, mr = 10, mt = 12, mb = 26, pw = W - ml - mr, ph = H - mt - mb,
        srt = [...fin].sort((a, b) => a - b), mx0 = srt[0], q = srt[Math.min(srt.length - 1, Math.floor(srt.length * .95))],
        hi = Math.max(q * 1.08, mx0 + 10), lo = Math.max(0, mx0 - (hi - mx0) * .06),
        X = i => ml + (n > 1 ? i / (n - 1) : .5) * pw, Y = x => mt + (1 - (Math.min(x, hi) - lo) / (hi - lo)) * ph,
        roll = k => { const pts = []; for (let i = k; i <= n; i++) { const a = aoW(v.slice(i - k, i), k); if (isFinite(a)) pts.push(X(i - 1).toFixed(1) + ',' + Y(a).toFixed(1)); } return pts.join(' '); };
  // straight trend line through the finished solves (least squares)
  let sx = 0, sy = 0, sxy = 0, sxx = 0, c = 0;
  v.forEach((y, i) => { if (!isFinite(y)) return; c++; sx += i; sy += y; sxy += i * y; sxx += i * i; });
  const den = c * sxx - sx * sx, m = den ? (c * sxy - sx * sy) / den : 0, b0 = (sy - m * sx) / c, change = m * (n - 1);
  let g = '';
  for (let k = 0; k <= 4; k++) {
    const t = lo + (hi - lo) * k / 4, y = Y(t).toFixed(1);
    g += `<line x1="${ml}" x2="${W - mr}" y1="${y}" y2="${y}" stroke="var(--line)" stroke-width="1"/><text x="${ml - 6}" y="${(+y + 4).toFixed(1)}" text-anchor="end" font-size="11" fill="var(--mut)">${fx(t)}</text>`;
  }
  [0, Math.round((n - 1) / 2), n - 1].filter((x, i, a) => a.indexOf(x) === i).forEach(i => { g += `<text x="${X(i).toFixed(1)}" y="${H - 6}" text-anchor="middle" font-size="11" fill="var(--mut)">${i + 1}</text>`; });
  const r = n > 400 ? 1.6 : n > 120 ? 2.2 : 3;
  g += v.map((y, i) => {
    const x = X(i).toFixed(1);
    if (!isFinite(y)) return `<path d="M${(+x - 3).toFixed(1)} ${mt + 1}l6 6m0 -6l-6 6" stroke="#e74c3c" stroke-width="1.6" fill="none"><title>#${i + 1} DNF</title></path>`;
    const ys = Y(y).toFixed(1), clipped = y > hi;
    return `<circle cx="${x}" cy="${ys}" r="${L[i].pb ? r + 1.8 : r}" fill="${L[i].pb ? '#f1c40f' : clipped ? 'none' : 'var(--mut)'}" ${clipped ? 'stroke="var(--mut)"' : ''} opacity="${L[i].pb ? 1 : .7}"><title>#${i + 1} · ${fmtS(L[i])}${L[i].pb ? ' ★ PB' : ''}</title></circle>`;
  }).join('');
  g += `<line x1="${X(0).toFixed(1)}" y1="${Y(b0).toFixed(1)}" x2="${X(n - 1).toFixed(1)}" y2="${Y(b0 + m * (n - 1)).toFixed(1)}" stroke="var(--fg)" stroke-width="1.6" stroke-dasharray="5 4" opacity=".65"/>`;
  if (n >= 12) g += `<polyline points="${roll(12)}" fill="none" stroke="var(--rd)" stroke-width="2.2" stroke-linejoin="round" stroke-linecap="round"/>`;
  if (n >= 5) g += `<polyline points="${roll(5)}" fill="none" stroke="var(--ac)" stroke-width="2.2" stroke-linejoin="round" stroke-linecap="round"/>`;
  const k = Math.min(10, Math.floor(fin.length / 2)), fm = mn(fin.slice(0, k)), lm = mn(fin.slice(-k)), d = fm - lm,
        tile = (l, x, sub) => `<div><small>${l}</small><b>${x}</b>${sub ? `<small>${sub}</small>` : ''}</div>`,
        verdict = fin.length < 6 ? '' : Math.abs(d) < 10 ? `Your times are steady: your last ${k} solves average about the same as your first ${k}.`
          : d > 0 ? `📈 You are getting faster! Your last ${k} solves average ${fx(lm)}, which is ${ds(d)}s (${(d / fm * 100).toFixed(0)}%) faster than your first ${k} (${fx(fm)}).`
          : `Your last ${k} solves average ${fx(lm)}, ${ds(d)}s slower than your first ${k} (${fx(fm)}). That is normal: tired hands, or a rough patch. The averages tell the real story.`;
  open(head +
    `<svg viewBox="0 0 ${W} ${H}" width="100%" role="img" aria-label="Solve times over ${n} solves">${g}</svg>` +
    `<div class="chips lg"><span><i style="background:var(--mut)"></i>each solve</span>${n >= 5 ? '<span><i style="background:var(--ac)"></i>ao5</span>' : ''}${n >= 12 ? '<span><i style="background:var(--rd)"></i>ao12</span>' : ''}<span><i style="background:var(--fg);opacity:.65"></i>trend</span><span><i style="background:#f1c40f"></i>PB ★</span></div>` +
    `<p class="lead" style="margin:10px 0 6px">${verdict}</p>` +
    `<div class="dtiles">${tile('Solves', n)}${tile('Best', fx(srt[0]))}${tile('Mean', fx(mn(fin)))}${tile('Current ao5', fx(aoN(v, 5)))}${tile('Trend', (change <= 0 ? '−' : '+') + ds(change) + 's', change <= 0 ? 'faster over these solves' : 'slower over these solves')}</div>`);
}

// Full "Today" window (opened from the top-right box on phones): goal, streak, week, numbers and rounds.
function todayInfo() {
  const r = roundsHtml(D());
  open('<h3>Today</h3><button class="on" data-a="pg" data-s="day" style="width:100%;margin-bottom:6px">📈 Progress graph</button><div class="dcard">' + (goalPanel() || '<p class="lead">No solves yet today.</p>') + '</div>' + (r ? '<h4>Rounds</h4><div class="rdl">' + r + '</div>' : ''));
}

// Popup for one solve (scramble, time, +2 / DNF / delete).
function openSolve(i) {
  sel = i;
    const s = D().solves[sel];
    open(`<h3>#${sel + 1} · ${fmtS(s)}</h3><div style="white-space:pre-line;font-family:ui-monospace,monospace;margin-bottom:8px">${esc(s.s || '(scramble not kept)')}</div><small style="color:var(--mut)">${new Date(s.d).toLocaleString()}</small>${solveInfo(s)}${view ? '' : `<div class="row btns"><span class="seg" role="group" aria-label="Penalty"><button data-a="p2" class="${s.p === 2 ? 'on' : ''}" title="Add a 2 second penalty (key 2)">+2</button><button data-a="dnf" class="${s.p === 'D' ? 'on' : ''}" title="Did not finish (key D)">DNF</button></span><button data-a="del" class="danger" title="Delete this solve">Delete</button></div>`}`);
}

// ---- Import: merge a saved file into the data that is already here (no solve is added twice) ----
let pendImp = null;
// the scramble is only part of the key for very old solves without a time stamp (old scrambles can be dropped, see Settings)
const skey = y => (y.d || 0) + '|' + y.t + (y.d ? '' : '|' + (y.s || '')),
      countAll = o => Object.values(o.data || {}).reduce((a, e) => a + e.solves.length, 0) + Object.values(o.hist || {}).reduce((a, h) => a + Object.values(h).reduce((b, e) => b + e.solves.length, 0), 0);

// Adds the incoming solves of one cube on one day to an existing entry. If the two files were
// never the same session their round numbers would clash, so the later group is renumbered after the earlier one.
function mergeEntry(cur, incoming) {
  const seen = new Set(cur.solves.map(skey));
  let nb = incoming.filter(y => !seen.has(skey(y)));
  const rm = L => Math.max(0, ...L.map(y => y.r || 0)), shift = (L, off) => L.map(y => y.r ? { ...y, r: y.r + off } : y);
  if (nb.length === incoming.length && cur.solves.length && nb.length) {
    if ((nb[0].d || 0) < (cur.solves[0].d || 0)) cur.solves = shift(cur.solves, rm(nb));
    else nb = shift(nb, rm(cur.solves));
  }
  cur.solves = cur.solves.concat(nb).sort((x, y) => (x.d || 0) - (y.d || 0));
  fixRounds(cur);
  return cur;
}

// "Also import settings and look" tick box in the import window.
const wantSet = () => { const c = document.getElementById('impset'); return !!(c && c.checked); };

// Carries the file's settings, view and wallpaper over. Settings missing from an old file keep their defaults.
function applySet(N, J) {
  N.set = { ...defSet(), ...(N.set || {}), ...(J.set || {}) };
  if (J.view) N.view = J.view;
  if (J.wall && /^data:image\//.test(J.wall)) { try { localStorage.setItem('ct2wall', J.wall); WALL = J.wall; } catch (e) {} }
  return N;
}

function mergeState(J) {
  const M = JSON.parse(JSON.stringify(S)), blank = () => ({ solves: [], rounds: [], round: 1 });
  M.data = M.data || {}; M.hist = M.hist || {}; M.rec = M.rec || {}; M.rec.c = M.rec.c || {}; M.known = M.known || {};
  for (const c of J.custom || []) { M.custom = M.custom || []; if (!M.custom.some(x => x.id === c.id)) M.custom.push(JSON.parse(JSON.stringify(c))); }
  const into = (day, id, list) => {
    if (!list || !list.length) return;
    const inc = JSON.parse(JSON.stringify(list));
    if (day === M.day) M.data[id] = mergeEntry(M.data[id] || blank(), inc);
    else { const h = (M.hist[day] = M.hist[day] || {}); h[id] = mergeEntry(h[id] || blank(), inc); }
  };
  for (const day in J.hist || {}) for (const id in J.hist[day]) into(day, id, J.hist[day][id].solves);
  for (const id in J.data || {}) into(J.day || M.day, id, J.data[id].solves);
  M.known = { ...(J.known || {}), ...M.known };
  for (const id in (J.rec && J.rec.c) || {}) {
    const a = M.rec.c[id] || {}, b = J.rec.c[id];
    M.rec.c[id] = { ...b, ...a, streak: Math.max(a.streak || 0, b.streak || 0), days: Math.max(a.days || 0, b.days || 0) };
  }
  M.rec.days = Math.max(M.rec.days || 0, (J.rec && J.rec.days) || 0);
  M.stime = M.stime || {};
  for (const k in J.stime || {}) M.stime[k] = Math.max(M.stime[k] || 0, J.stime[k] || 0);
  return M;
}

// Popup for one round: result, dropped times, and every solve of that round (click one to open it).
function openRound(n) {
  const d = D(), I = d.solves.map((_, i) => i).filter(i => d.solves[i].r === n);
  if (!I.length) return;
  const L = I.map(i => d.solves[i]), v = L.map(val), full = L.length === 5,
        lo = full ? v.indexOf(Math.min(...v)) : -1, hi = full ? v.indexOf(Math.max(...v)) : -1,
        r = d.rounds.find(x => x.n === n), res = r ? r.res : NaN,
        pbR = r && d.rounds.length > 1 && res === minOf(d.rounds.map(x => x.res).filter(isFinite));
  const dn = L[L.length - 1].d, tdone = dn ? new Date(dn).toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' }) : '';
  open(`<h3>Round ${n}${L.length === 5 && r ? ' · ' + fx(res) + ' (ao5)' + (pbR ? ' ★' : '') : ' · ' + L.length + ' of 5 solves' + (r ? ' (no ao5)' : ' (in progress)')}${tdone ? ` <span style="font-weight:400;color:var(--mut);font-size:.8em">· ${L.length === 5 ? 'done at' : 'last solve at'} ${tdone}</span>` : ''}</h3>` +
    `<div class="chips">${L.map((s, k) => {
      const t = fmtP(s), w = full && (k === lo || k === hi) ? '(' + t + ')' : t;
      return `<button data-a="solve" data-i="${I[k]}"><small>${ORD[k]}</small> <b>${w}</b></button>`;
    }).join('')}</div>` +
    (full ? `<div class="dtl">Best and worst are dropped (in brackets). The ao5 is the mean of the other three.</div>` : '') +
    L.map((s, k) => `<div class="dtl"><b>${ORD[k]}</b> · <span style="font-family:ui-monospace,monospace;white-space:pre-line">${esc(s.s || '(scramble not kept)')}</span></div>`).join(''));
}

migrate();
rollover();
if (trimScr()) save();
applyTheme();
newScr();
render();

// Optional: use the Rust/WebAssembly versions when pkg/ is built and served over http.
(async () => {
  try {
    const m = await import('./pkg/cubetimer.js');
    await m.default();
    ({ scramble, ao5, stats, insp, insp_text } = m);
    F = m.fmt;
    render();
    console.log('Rust core loaded');
  } catch (e) {
    console.log('Using JavaScript core');
  }
})();

// Small top view of a last-layer case for the Methods window.
// 'o' + 9 top and 12 side digits (1 yellow, 0 other, 2 any) for OLL, or 'p' + 12 side letters (F R B L = that face's colour) for PLL.
function dg(c) {
  const k = 14, g = 2, w = 5, m = 2, o = w + m, n = 3 * k + 2 * g, t = n + 2 * o;
  const col = { F: '#34a853', R: '#f28c28', B: '#3b7ddd', L: '#d94a3d', 1: '#f5c400', 0: 'color-mix(in srgb, var(--fg) 28%, var(--bg))', 2: 'color-mix(in srgb, var(--fg) 12%, var(--bg))' };
  const q = (x, y, a, b, v) => `<rect x="${x}" y="${y}" width="${a}" height="${b}" rx="2" style="fill:${col[v]}"/>`;
  const s = c.slice(1), top = c[0] === 'o' ? s.slice(0, 9) : '111111111', side = c[0] === 'o' ? s.slice(9) : s;
  let r = '';
  for (let i = 0; i < 9; i++) r += q(o + (i % 3) * (k + g), o + Math.floor(i / 3) * (k + g), k, k, top[i]);
  for (let i = 0; i < 12; i++) {
    const e = (k + g) * (i % 3);
    r += i < 3 ? q(o + e, 0, k, w, side[i]) : i < 6 ? q(o + n + m, o + e, w, k, side[i]) : i < 9 ? q(o + e, o + n + m, k, w, side[i]) : q(0, o + e, w, k, side[i]);
  }
  return `<svg class="dg" viewBox="0 0 ${t} ${t}" aria-hidden="true">${r}</svg>`;
}

function methods(m, t) {
  const c = curCube();
  if (!c.meth) {
    open(`<h3>${esc(c.n)} notes</h3><p class="lead">Your own cube. Write your method, algs or tips here. They are saved.</p><textarea id="nt" class="notes" placeholder="Method, algs, tips...">${(c.notes || '').replace(/&/g, '&amp;').replace(/</g, '&lt;')}</textarea>`);
    return;
  }
  const MS = Object.fromEntries(c.meth.map(k => [k, M[k]])), st = S.view;
  if (!MS[st.m]) { st.m = c.meth[0]; st.t = Object.keys(MS[st.m].sub)[0]; }
  if (m) {
    if (m !== st.m || t) st.t = t || Object.keys(MS[m].sub)[0];
    st.m = m;
  }
  const me = MS[st.m], ks = Object.keys(me.sub);
  if (!me.sub[st.t]) st.t = ks[0];
  const d = me.sub[st.t];
  save();
  const A = d.algs.filter(a => a[0] !== '#' && a[0] !== 't'),
        kn = A.filter(a => S.known[a[1]]).length;
  open(`<h3>Methods · ${esc(c.n)} <small class="lead" id="kc">${A.length ? kn + ' / ' + A.length + ' known' : ''}</small></h3><div class="row tabs">${Object.keys(MS).map(k => `<button data-a="mt" data-m="${k}" class="${k === st.m ? 'on' : ''}">${MS[k].n}</button>`).join('')}</div>${ks.length > 1 ? `<div class="row tabs">${ks.map(k => `<button data-a="mt" data-m="${st.m}" data-t="${k}" class="${k === st.t ? 'on' : ''}">${me.sub[k].n}</button>`).join('')}</div>` : ''}<p class="lead">${d.info}</p>${A.length ? '' : '<p class="lead">No algs in this step. It is solved by thinking and practice, so there is nothing to tick.</p>'}${d.tips.length ? `<ul style="padding-left:18px">${d.tips.map(x => `<li>${x}</li>`).join('')}</ul>` : ''}${d.algs.map(a => a[0] === '#' ? `<h4>${a[1]}</h4>` : a[0] === 't' ? `<p style="margin:6px 0">${a[1]}</p>` : `<label class="alg"><input type="checkbox" data-alg="${a[1]}" ${S.known[a[1]] ? 'checked' : ''}>${a[3] ? dg(a[3]) : ''}<b>${a[0]}</b><code>${a[1]}</code>${a[2] ? `<span class="nt">${a[2]}</span>` : ''}</label>`).join('')}`);
  dl.scrollTop = 0;
}

dl.addEventListener('change', e => {
  if (e.target.id === 'wf') {
    const f = e.target.files[0];
    if (!f) return;
    const img = new Image(), u = URL.createObjectURL(f);
    img.onload = () => {
      const m = Math.min(1, 1920 / Math.max(img.width, img.height)), c = document.createElement('canvas');
      c.width = Math.round(img.width * m); c.height = Math.round(img.height * m);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      let q = 0.82, d = c.toDataURL('image/jpeg', q);
      while (d.length > 2.5e6 && q > 0.3) { q -= 0.1; d = c.toDataURL('image/jpeg', q); }
      URL.revokeObjectURL(u);
      try { localStorage.setItem('ct2wall', d); WALL = d; } catch (err) { alert('This picture is too big to save in this browser. Try a smaller one.'); }
      applyTheme(); wallPrev();
    };
    img.onerror = () => { URL.revokeObjectURL(u); alert('Could not read that picture.'); };
    img.src = u;
    e.target.value = '';
    return;
  }
  const a = e.target.dataset.alg;
  if (a === undefined) return;
  if (e.target.checked) S.known[a] = 1;
  else delete S.known[a];
  save();
  const c = [...dl.querySelectorAll('[data-alg]')];
  $('#kc').textContent = c.filter(x => x.checked).length + ' / ' + c.length + ' known';
});

// Everything below keeps this computer and the account on the server in step.
// Rules: only changes made on one side -> the newer side wins. Changes on both sides -> they are merged
// (no solve is lost or added twice; a solve deleted on one side can come back in that rare case).
function afterSwap(merged) {
  S.known = S.known || {};
  S.view = S.view || { m: 'cfop', t: 'ov' };
  S.hist = S.hist || {};
  S.rec = S.rec || {};
  undoDel = [];
  AOC = {};
  if (merged) for (const id of new Set([...Object.keys(S.data || {}), ...Object.values(S.hist).flatMap(h => Object.keys(h))])) { repb(id); repRec(id); }
  migrate();
  rollover();
  histCheck = true;
  persist();
  applyTheme();
  newScr();
  render();
}

async function pull() {
  if (!location.protocol.startsWith('http') || !AUTH || mode !== 'idle') return;
  setSync('busy');
  try {
    const resp = await api('state'), sv = resp.state, st = syncedTs();
    if (resp.d) canDelta = true;
    if (!sv) { fullPush = true; await doPush(); return; }                        // new account: upload what is on this computer
    const local = (S.ts || 0) > st;                              // changed here since the last sync
    if (sv.ts === st) { if (local) await doPush(); else setSync('ok'); return; }
    if (local && (countAll(S) || (S.custom && S.custom.length))) {                                  // changed on both sides: merge
      const M = mergeState(sv);
      M.set = { ...M.set, ...(sv.set || {}) };
      S = M;
      S.ts = Math.max(Date.now(), (sv.ts || 0) + 1);
      setSyncedTs(sv.ts || 0);
      fullPush = true;   // the merged result differs from the server: send it whole once
      afterSwap(true);
      save();
    } else {                                                     // only the server changed: take it
      S = { ...S, ...sv, set: { ...S.set, ...sv.set } };
      setSyncedTs(sv.ts || 0);
      afterSwap(false);
      for (const d in histU) delete histU[d];
      Object.assign(histU, histH);   // this device now holds exactly what the server holds
      fullPush = false;
      setSync('ok');
    }
  } catch (e) {
    setSync(AUTH ? 'err' : 'off');
  }
}

const sleep = ms => new Promise(r => setTimeout(r, ms));

// Removes everything personal from this computer (used by log out and delete account).
function wipeLocal() {
  LOCKED = true;
  clearTimeout(pt);
  try {
    for (const k of ['ct2', 'ct2sync', 'ct2auth', 'ct2wall']) localStorage.removeItem(k);
    for (let i = localStorage.length - 1; i >= 0; i--) { const k = localStorage.key(i); if (k && k.startsWith(HK)) localStorage.removeItem(k); }
  } catch (e) {}
}

async function logout() {
  if (AUTH) {
    clearTimeout(pt);
    for (let i = 0; pushing && i < 50; i++) await sleep(100);
    const ok = (S.ts || 0) <= syncedTs() || await doPush();   // send the latest solves first
    if (!ok && !confirm('Your latest solves could not be sent to the server. Log out anyway? They will be lost on this computer.')) return;
    try { await api('logout', 'POST', {}); } catch (e) {}
  }
  wipeLocal();
  location.reload();
}

let acctTab = 'in';
function acMsg(t, k) {
  const el = document.getElementById('acmsg');
  if (el) { el.textContent = t || ''; el.className = 'acmsg ' + (k || ''); }
}

// The Account window: log in / create account, or the profile when signed in.
function account() {
  if (!location.protocol.startsWith('http')) {
    open('<h3>Account</h3><p class="lead">Accounts need the timer to be opened from a web address (http or https), not from a file on your computer.</p>');
    return;
  }
  const f = (n, l, t, ac, extra = '') => `<label>${l}<input name="${n}" type="${t}" autocomplete="${ac}" required ${extra}></label>`,
        un = 'autocapitalize="off" spellcheck="false" maxlength="24"';
  if (AUTH) {
    open(`<h3>Profile</h3><p id="acmsg" class="acmsg" role="alert"></p>
<section class="dcard sg"><h4>Signed in as ${esc(AUTH.user)}</h4>
<p class="lead">Your solves, records and settings are saved on the server. Log in with this username and password on any computer to see them there.</p>
<div class="set"><span class="lb">Sync status</span><b id="acst">${esc(SYNC_TXT[syncSt])}</b></div>
<div class="row btns"><button data-acct="sync">Sync now</button><button data-acct="out">Log out</button></div></section>
<section class="dcard sg"><h4>Change password</h4>
<form class="acform" data-acct-form="pw"><input type="text" name="username" value="${esc(AUTH.user)}" autocomplete="username" hidden>
${f('current', 'Current password', 'password', 'current-password')}${f('next', 'New password (at least 8 characters)', 'password', 'new-password', 'minlength="8"')}${f('next2', 'New password again', 'password', 'new-password', 'minlength="8"')}
<button type="submit">Change password</button></form></section>
<section class="dcard sg"><h4>Delete account</h4>
<p class="lead">Deletes your account and all its solves from the server, and clears this computer. It cannot be undone. Tip: use Export data in Settings first.</p>
<form class="acform" data-acct-form="del"><input type="text" name="username" value="${esc(AUTH.user)}" autocomplete="username" hidden>
${f('password', 'Your password', 'password', 'current-password')}<button type="submit" class="danger">Delete my account</button></form></section>`);
  } else {
    const up = acctTab === 'up';
    open(`<h3>Account</h3><div class="row tabs"><button data-acct="tab" data-t="in" class="${up ? '' : 'on'}">Log in</button><button data-acct="tab" data-t="up" class="${up ? 'on' : ''}">Create account</button></div>
<p class="lead">${up ? 'Pick a username and a password. Your solves on this computer are added to the new account, and you can log in with it on any other computer.' : 'Log in to get all your solves, records and settings on this computer. Solves already on this computer are added to your account.'}</p>
<p id="acmsg" class="acmsg" role="alert"></p>
<form class="acform" data-acct-form="${up ? 'up' : 'in'}">
${f('username', 'Username', 'text', 'username', un)}${f('password', 'Password' + (up ? ' (at least 8 characters)' : ''), 'password', up ? 'new-password' : 'current-password', up ? 'minlength="8"' : '')}${up ? f('confirm', 'Password again', 'password', 'new-password', 'minlength="8"') : ''}
<button type="submit" class="on">${up ? 'Create account' : 'Log in'}</button></form>
${up ? '<p class="lead">Username: 3 to 24 letters, numbers, _ . or -</p>' : ''}`);
  }
}

dl.addEventListener('click', async e => {
  const b = e.target.closest('[data-acct]');
  if (!b) return;
  const a = b.dataset.acct;
  if (a === 'tab') { acctTab = b.dataset.t; account(); }
  else if (a === 'sync') {
    b.disabled = true;
    await pull();
    for (let i = 0; pushing && i < 50; i++) await sleep(100);
    b.disabled = false;
    acMsg(syncSt === 'ok' ? 'Synced.' : SYNC_TXT[syncSt], syncSt === 'ok' ? 'ok' : 'bad');
  } else if (a === 'out') {
    if (confirm('Log out? Your solves stay in your account. They are removed from this computer.')) logout();
  }
});

dl.addEventListener('submit', async e => {
  const f = e.target.closest ? e.target.closest('[data-acct-form]') : null;
  if (!f) return;
  e.preventDefault();
  const v = n => (f.elements[n] ? f.elements[n].value : ''), kind = f.dataset.acctForm, btn = f.querySelector('button[type=submit]');
  if (btn) btn.disabled = true;
  try {
    if (kind === 'in' || kind === 'up') {
      if (kind === 'up' && v('password') !== v('confirm')) throw new Error('The two passwords are not the same.');
      const r = await api(kind === 'in' ? 'login' : 'register', 'POST', { username: v('username').trim(), password: v('password') });
      setAuth({ token: r.token, user: r.username });
      setSyncedTs(0);
      setSync('busy');
      await pull();
      account();
      acMsg(syncSt === 'err' ? 'Logged in, but the solves could not be synced yet.' : 'Welcome, ' + AUTH.user + '! Your solves are synced.', syncSt === 'err' ? 'bad' : 'ok');
    } else if (kind === 'pw') {
      if (v('next') !== v('next2')) throw new Error('The two new passwords are not the same.');
      await api('password', 'POST', { current: v('current'), next: v('next') });
      account();
      acMsg('Password changed. Other computers will need to log in again.', 'ok');
    } else if (kind === 'del') {
      if (!confirm('Delete the account "' + AUTH.user + '" and all its solves on the server? This cannot be undone.')) { if (btn) btn.disabled = false; return; }
      await api('delete', 'POST', { password: v('password') });
      wipeLocal();
      location.reload();
    }
  } catch (err) {
    acMsg(err.message, 'bad');
    if (btn) btn.disabled = false;
  }
});

pull();
document.addEventListener('visibilitychange', () => {
  if (!document.hidden) { if (mode === 'idle' && rollover()) { tm.textContent = '0.00'; render(); } pull(); }
  else { histCheck = true; persist(); }   // keep the last screen time when the tab is left
});
setInterval(() => { if (mode === 'idle' && !dl.open && rollover()) { tm.textContent = '0.00'; render(); } }, 30000);
setInterval(() => { if (AUTH && !document.hidden && mode === 'idle' && !dl.open) pull(); }, 90000);   // pick up solves done on another computer

keyLabels();
updateAcct();
